from flask import Flask, render_template

app = Flask(__name__, template_folder="D:/pyqt_tool/flask_venu",static_folder='D:/pyqt_tool/flask_venu/static', static_url_path='/static')

@app.route("/")
def home():
    return render_template("/dev_view_script.html")

@app.route("/dev_view_script")
def dev_view_script():
    return render_template("dev_view_script.html")

@app.route("/dev_edit_script")
def dev_edit_script():
    return render_template("dev_edit_script.html")

@app.route("/control")
def control():
    return render_template("control.html")

@app.route("/dev_import_export")
def dev_import_export():
    return render_template("dev_import_export.html")

@app.route("/status")
def status():
    return render_template("status.html")

@app.route("/system_settings")
def system_settings():
    return render_template("system_settings.html")

@app.route("/dev_import")
def dev_import():
    return render_template("dev_import.html")

@app.route("/debug_tools")
def debug_tools():
    return render_template("debug_tools.html")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
