upass='';
uuser='';
GotoNextPage='';
RemoteAccessToken='';
isRemoteAccess=false;
			var ws;
			isWebsocketConnect=false;
			//----Get WS URL-----//
			var WsHostDomain;
 
			var WsHostPort=8088;
			var WsURL="";
 
			toRcver='';
			
			RemoteAccessToken='';
			IPTRemoteAccessToken='';
		
			WsHostDomain=document.domain;  
 			
			WsHostDomain_Def='';
 
			WsURL_Def="ws://"+WsHostDomain+":"+WsHostPort;
			
			WsHostPort=WsHostDomain+":"+WsHostPort;
			
			WsURL="ws://"+WsHostPort;
			
			var TickCount=0;
			var myTick;
			var myInterval;
			
			var FileEdited=false;

		
			$("#Host").val(WsHostPort);
			
function BeforeConnect()
{
			var WsURL_= $.cookie('SimFAS_WsURL') ;
			if ((WsURL_.length>10) && (WsHostDomain_Def.length<10))
				WsURL=WsURL_;
			else
				WsURL=WsURL_Def;
			
			ShowStatus(1);
			
			
	
}			
function LoginDev(user,pass)
{
	ShowStatus(4);
	isWebsocketConnect=true;
	var _RemoteAccessToken=$.cookie('SimFAS_RemoteAccessToken');
	if (user.length<2)	user=($.cookie('SimFAS_Username'));
	if (pass.length<2)  pass=($.cookie('SimFAS_Password'));
	
	toRcver=$.cookie('toRcver');
	if ((toRcver) && (toRcver.length<1)) {toRcver=user}
			
	
	if (((typeof(_RemoteAccessToken) != "undefined") )&&(_RemoteAccessToken.length>0)) 
	{
		RemoteAccessToken=Base64_encode(_RemoteAccessToken);
	}
	else
	RemoteAccessToken=Base64_encode(IPTRemoteAccessToken);
 
	//uuser=Base64_encode(user);
	uuser=user;
	if (typeof(pass) != "undefined")	upass=Base64_encode(pass);
	
	var jsondata="{\"Type\":\"Login\",\"uType\":\"Login\",\"Enc\":1,\"User\":\""+uuser+"\",\"Pass\":\""+upass+"\",\"VerID\":\"V2\"}";
	var jdata=formatDataLen(jsondata.length+5)+jsondata;
	if (ws)
	{
		ws.send(jdata); 
		myname=user;
	}
	ShowInfo_LabelStatus("正在验证登录!");
	log(WsURL+'\n'+jdata);
}



function ProcessDisconnect(data)
{
	//ShowMessageBox("Info","Disconnected from remote server.");
	isWebsocketConnect=false;
	ws=null;
	clearInterval(myInterval);
	if (winLostFocus==0)		setTimeout(WS_Connect(),4000);	
	ShowStatus(0);
	ShowInfo_LabelStatus("错误:设备已断开!");
				
	
}

function ProcessLoginMessage(msg,GotoNextPage)
{
	var pos=5;		
	pos=msg.indexOf("{");
	jsonstr=msg.substring(pos);
	var jdata = eval("(" + jsonstr + ")");
	if ((typeof(jdata['Type']) ==="undefined")) {return -1;}
 
	switch	(jdata['Type'])
	{
 
	case 'auth' :
		if (jdata['status']==1)
		{
			log("设备已连接");

			ShowInfo_LabelStatus("设备已连接");
			user=$("#user").val();
			pass=$("#password").val();	
			if (GotoNextPage===undefined)
			var GotoNextPage="dev_view_script.html";
			window.location.href=GotoNextPage;
		}
		else
		{
			if ($("#ErrorInfo").size()>0)
			{
				$("#ErrorInfo").html("<br\>登录失败，请检查您的用户名和密码!"); 

				$("#Div_ErrorInfo").show(1200);
			}
			else
			{
				var GotoNextPage="index.html";
				window.location.href=GotoNextPage;		
				
			}
			
		}
 		
 	break;
	}
}	

function ProcessSysInfoMessage(msg)
{
	var pos=5;		
	pos=msg.indexOf("{");
	jsonstr=msg.substring(pos);
	var jdata = eval("(" + jsonstr + ")");
	if ((typeof(jdata['Type']) ==="undefined")) {return -1;}
 
	switch	(jdata['Type'])
	{
 
	case 'auth' :
		if (jdata['status']==1)
		{
			log("设备已连接");

			ShowInfo_LabelStatus("设备已连接")
			SendRequest_sysinfo("_reqSysinfo.tsk");
			if (typeof(myInterval) ==="undefined")
			myInterval=setInterval("SendRequest_sysinfo('_reqSysinfo.tsk')","5000");
		}
 	else
	{
			ShowInfo_LabelStatus("登录失败，请检查您的用户名和密码!");

			var GotoNextPage="index.html";
			window.location.href=GotoNextPage;	
	}
 	break;
 
 
 case 'Msg': 
 	
		var mymsg=jdata['Msg'];
		var uType=jdata['uType'];
		var mtype=jdata['mType'];
		var content=mymsg;
		ShowProcessStatus();
		
		if (mtype>0)
		{
			var content=Base64_decode(mymsg);
		}
		
		ShowSysinfo(content);
		
		
 
 	break;
 
 
 }
		
	
	
}

function ProcessViewSettingsMessage(data)
{
	
	var pos=5;		
	pos=msg.indexOf("{");
	jsonstr=msg.substring(pos);
	var jdata = eval("(" + jsonstr + ")");
	if ((typeof(jdata['Type']) ==="undefined")) {return -1;}
 
	switch	(jdata['Type'])
	{
 
	case 'auth' :
		if (jdata['status']==1)
		{
			log("设备已连接");

			ShowInfo_LabelStatus("设备已连接")
			SendRequest_UCI_GET("-all",'network');
			setTimeout("SendRequest_UCI_GET('-all','application')",500);
			setTimeout("SendRequest_UCI_GET('-all','')",1000);
			setTimeout("SendRequest_sysinfo('_reqSysinfo.tsk')",2000);
			

		}
 	else
	{
			ShowInfo_LabelStatus("登录失败，请检查您的用户名和密码!");

			var GotoNextPage="index.html";
			window.location.href=GotoNextPage;	
	}
 	break;
 
 
 case 'Msg': 
 	
		var mymsg=jdata['Msg'];
		var uType=jdata['uType'];
		var mtype=jdata['mType'];
		var content=mymsg;
		
		ShowProcessStatus();
		
		
		if ( (mtype>0) || (jdata['usrType']=='UCIR' ) )
		{
			var content=Base64_decode(mymsg);
			log(content);
			ShowSettingsinfo(content,jdata['theKey']);
		}
		
		if (jdata['usrType']=='UCIW' )
		{
			
			var content=Base64_decode(mymsg);
			ShowInfo_LabelStatus("设置成功保存!"+content);
			$("#buttonSaveNetwork").removeAttr("disabled");
			
			setTimeout("SendRequest_sysinfo('_reqSysinfo.tsk')",3000);
			
			
		}else if (jdata['usrType']!='UCIR' )
		{	
			var content=Base64_decode(mymsg);
 
			ShowSysinfo(content);
		}
		
		
		
		
		
 
 	break;
 
 
 }
	
	
	
}

var idxDBForSearch='';

function ProcessViewIdxMessage(msg,isControlPage)
{
	var pos=5;		
	pos=msg.indexOf("{");
	jsonstr=msg.substring(pos);
	var jdata = eval("(" + jsonstr + ")");
	if ((typeof(jdata['Type']) ==="undefined")) {return -1;}
 
	switch	(jdata['Type'])
	{
 
	case 'auth' :
		if (jdata['status']==1)
		{
			log("设备已连接");

			ShowInfo_LabelStatus("设备已连接")
			SendRequest_LoadIdx(upass);
		}
		else
		{
			log("登录失败，请检查您的用户名和密码!");

			var GotoNextPage="index.html";
			window.location.href=GotoNextPage;		
 		}
 	break;
 
 
 case 'Msg': 
 
		var mymsg=jdata['Msg'];
		var uType=jdata['uType'];
		var Filename_=jdata['Filename'];
		var Filename='';
		ShowProcessStatus();
		if ((Filename_) && (Filename_.length>0))	Filename=Base64_decode(Filename_); 	
		var content=Base64_decode(mymsg);
		if (!(typeof(Filename) ==="undefined")) 
		{  
			if (Filename.indexOf("index.db")>-1)
			{
				var storage=window.localStorage;
				
				if (storage) {storage.setItem("Sim_Index_Db",content);}
				
				
				ExtracIdx(content);
				
				idxDBForSearch=content;
				
				if (isControlPage==1)
				{
					
					ExtracIdxToControl(content);
				}
			}
		}
		
		if ((typeof(uType) ==="undefined") && jdata['mType'] && (jdata['mType']==1)  )
		{

			ShowInfo(mymsg,1000);
			ShowInfo_LabelStatus(mymsg);
			
		}
 
		if (!(typeof(uType) ==="undefined") && uType=='authR')
		{
			ShowInfo_LabelStatus(mymsg);
		}
 
 	break;
 
 
 }
 
 
 
			
}


function ProcessViewIR(msg,isControlPage)
{
	var pos=5;		
	pos=msg.indexOf("{");
	jsonstr=msg.substring(pos);
	var jdata = eval("(" + jsonstr + ")");
	if ((typeof(jdata['Type']) ==="undefined")) {return -1;}
 
	switch	(jdata['Type'])
	{
 
	case 'auth' :
		if (jdata['status']==1)
		{
			log("设备已连接");

			ShowInfo_LabelStatus("设备已连接")
			SendRequest_LoadIR(upass);
		}
		else
		{
			log("登录失败，请检查您的用户名和密码!");

			var GotoNextPage="index.html";
			window.location.href=GotoNextPage;		
 		}
 	break;
 
 
 case 'Msg': 
 
		var mymsg=jdata['Msg'];
		var uType=jdata['uType'];
		var Filename_=jdata['Filename'];
		var Filename='';
		ShowProcessStatus();
		if ((Filename_) && (Filename_.length>0))	Filename=Base64_decode(Filename_); 	
		var content=Base64_decode(mymsg);
		if (!(typeof(Filename) ==="undefined")) 
		{  
			if (Filename.indexOf("ir.db")>-1)
			{
				//var storage=window.localStorage;
				
				//if (storage) {storage.setItem("Sim_Index_Db",content);}
				
				ExtracIRIdx(content);
				

			}
		}
		
		if ((typeof(uType) ==="undefined") && jdata['mType'] && (jdata['mType']==1)  )
		{

			ShowInfo(mymsg,1000);
			ShowInfo_LabelStatus(mymsg);
			
		}
 
		if (!(typeof(uType) ==="undefined") && uType=='authR')
		{
			ShowInfo_LabelStatus(mymsg);
		}
 
 	break;
 
 
 }
 
 
 
			
}







function ShowSettingsinfo(message,theInterface)
{

		var i=0;
		var lines=message.split("\n");
		var uidata='';
 
		for(i=0;i<lines.length-1;i++)
			{ 
			uidata= lines[i].split("=");   
			var key=uidata[0];		
			if  ( (uidata.length==2) && ((key.length>0)) )
				{
				
				var value=uidata[1];
				
				if (theInterface == 'application' )
					ApplicationSettings[key]=value;
				
				
				if (value.length>48) value=value.substr(1,58)+'...';
				$("#"+key).val(value);
				if ((key=='WAN_DHCP') &&(value==0))
				{
					$('#WAN_DHCP_TIPS').hide();
					$('#Div_WAN_IP').show(500);
					
				}else if ((key=='LAN_DHCP') &&(value==0))
				{
					$('#Div_LAN_IP').hide(200);
					$('#LAN_NO_DHCP_TIPS').show(500);					
					
				}
				else if ((key=='IM_Enabled') &&(value==1))
				{
					$('#IMServiceTips').hide(100);
					$('#IM_Enabled').attr("checked", true);
					
				}

				else if ((key=='IM_assist') &&(value==1))
				{
					
					$('#IM_assist').attr("checked", true);
				}
				else if (key=='Device.UI.Admin.AccessToken')
				{
					$('#Admin_AccessToken').val(value);
			
					
				}
				else if (key=='IM_DefSubUser')
				{
					$('#IM_DefSubUser').val(value);
					
				}
				
				}
		     }
			 
				if (theInterface == 'application' )
				{
					$("#CloudHostPort").val(ApplicationSettings['IM_Host']+":"+ApplicationSettings['IM_Port']);
					$("#CloudIDPASS").val(ApplicationSettings['IM_User']+":"+ApplicationSettings['IM_Pass']);
				
					if (ApplicationSettings['IM_HostType']=="1")
					{	
					
					$('#DivCloudHostPort').show(100);
					var tokenstr="SIM"+ApplicationSettings['Device.UI.Admin.AccessToken']+"FAS";
					$("#AccessTokenStr").val(tokenstr);
 
					$("#Modal_Token_Label").html(tokenstr);


					jQuery('#Token_qrcode').qrcode({
					text	: "http://www.simfas.cn/ide/?token="+tokenstr
					});	
					
					jQuery('#Token_Control').qrcode({
					text	: "http://www.simfas.cn/ide/?ctrl=1&token="+tokenstr
					});		
					
					
					
					}
					else
					{
					var tokenstr=CreatTokenStr(ApplicationSettings['IM_DefHost'],ApplicationSettings['IM_DefPort'],ApplicationSettings['IM_DefSubUser'],ApplicationSettings['IM_DefSubPass'],ApplicationSettings['IM_DefUser'],ApplicationSettings['Device.UI.Admin.AccessToken']);
 
					tokenstr="SIM"+tokenstr+"FAS"
					$("#AccessTokenStr").val(tokenstr);
 
					$("#Modal_Token_Label").html(tokenstr);
					
					jQuery('#Token_qrcode').qrcode({
					text	: "http://www.simfas.cn/ide/?token="+tokenstr
					});	
					
					jQuery('#Token_Control').qrcode({
					text	: "http://www.simfas.cn/ide/?ctrl=1&token="+tokenstr
					});		

					
	
					
					$("#accesstokenCopy").show();
					
					//$("#statusToken").html(tokenstr);
					
						
					}		
					
					
					if (ApplicationSettings['IM_AccountType']==1) 	$('#DivCloudIDPASS').show(200);
					if (ApplicationSettings['IM_AccessType']==1) 	$('#DivTokenType').show(300);
				}
				
}


	
function ShowSysinfo(message)
{
		var updateDraw=false;
		var i=0;
		if ((!message)) return -1;
		var lines=message.split("\n");
		var uidata='';
		for(i=0;i<lines.length-1;i++)
			{ 
			uidata= lines[i].split("|");   
			var key=uidata[0];
			
			if  ( (uidata.length>2) && ((key.indexOf("/")<0)) )
				{
				
				var value=uidata[1];
				if (value.length>48) value=value.substr(1,58)+'...';
				$("#"+key).html(value);
				if (key===("MemUsedPer")) 
					{
						$("#"+key).html(value+'% (used)');
						$("#MemUsedPer").css('width',value+'%');
						//ShowDebugMsg(uidata[1]);
					}
				else if (key===("MemFreePer")) 
					{
						$("#"+key).html(value+'%');
						$("#MemFreePer").css('width',value+'%');					
					}
				else if (key===("dfFreePer")) 
					{
						$("#"+key).html(value+'% (free)');
						$("#dfFreePer").css('width',value+'%');					
					}
				else if (key===("dfUsedPer")) 
					{
						$("#"+key).html(value+'% (used)');
						$("#dfUsedPer").css('width',value+'%');						
					}
				else
				{
 
					SavedrawHomeLines(key,value);
					
				}
							
				//printLog(uidata[1],uidata[0]===("LabelCompileLog"));
				}
		     }

			 if (message.indexOf("Load")>0) {drawHomeLines();};
}	

function ExtracIdx(LineData)
{
	var lines;
	var items;
	var item;
	var i;
	var htmlcode="";
	
	var MyProData="";
	var DemoProData="";
	var classProData="";
	
	var itemno_=1;	
	var itemno=0;
	var ShowItemID=0;
	var filename="";
	var encFilename="";
	var ClassString="";
	var AppType=0;
	var AdvEng=0;
	var DefEngHtml="";
	var AdvEngHtml="";
	var ExportCheckBoxHTML="";
	lines=LineData.split("\n");
	for (i in lines)
	{
	 items=lines[i].split("|");
	 if (typeof(items[1])==="undefined")
	 {
	   
	 }
	 else
	 {
	 item=items[2].split("^");
	 itemno_++;
	 itemno=lines.length-itemno_;
	 filename=items[1];
	 AppType=
	 encFilename=encodeURIComponent(filename);
	 ShowItemID=itemno_-1;
	 //ClassString="icon-double-angle-right";
	 ClassString="icon-double-angle-right";
	 
	 if(filename.substr(0, 1) == "_") {
		 ClassString="icon-star-empty" ;
		 AdvEng=1;
	 }
	 else
	 {
		 AdvEng=0;		 
	 }
	 
	 AppType=parseInt(item[1]);
	 
	 if (items[0].indexOf("3,")>=0) ClassString="icon-time";
	 
	 
	 if ( typeof( ExportCheckBox_Show) === "undefined")
	 {
			ExportCheckBoxHTML="<i class=\""+ClassString+"\"></i> ";
		 
			EditHTML="<a href=\"dev_edit_script.html?id="+encFilename+"\" class=\"btn btn-primary btn-sm\" title=\"编辑程序\" ><i class=\"icon-edit\"></i> </a> <a href=\"dev_edit_script.html?id="+encFilename+"&act=cp\" class=\"btn btn-info btn-sm\" title=\"复制程序\" ><i class=\"icon-copy\"></i></a> <a href=\"javascript:SendRequest_DelFile('"+filename+"','');\"  class=\"btn btn-danger btn-sm\" title=\"删除程序\"><i class=\"icon-trash\"></i>  </a>  <a href=\"javascript:RunTask('"+filename+"','');\"  class=\"btn btn-success btn-sm \" title=\"运行程序\"><i class=\"icon-play\"></i>  </a>  "	 
	
		editHTML_SYS=" <a href=\"dev_edit_script.html?id="+encFilename+"\" class=\"btn btn-primary btn-sm\" title=\"编辑程序\"><i class=\"icon-edit\"></i> </a> <a href=\"dev_edit_script.html?id="+encFilename+"&act=cp\" class=\"btn btn-info btn-sm\"  title=\"复制程序\"><i class=\"icon-copy\"></i></a>  <a href=\"javascript:alert('System reserved!');\"  class=\"btn btn-danger btn-sm\" title=\"删除程序\"><i class=\"icon-trash\"></i>  </a>  <a href=\"javascript:RunTask('"+filename+"','');\"  class=\"btn btn-success btn-sm \" title=\"运行程序\" ><i class=\"icon-play\"></i>  </a>"
			
	}
		
	 else 
	 {
		if (AppType==6) 
			ExportCheckBoxHTML="<i class=\""+ClassString+"\"></i> ";
		else
			ExportCheckBoxHTML='<input type="checkbox" id="CheckBoxExportScripts" value="'+encFilename+'" /> '; 
		EditHTML='<a  class="btn btn-primary btn-sm" href="javascript:expTask(\''+encFilename+'\');"> <i class=\"icon-download-alt\"></i> 导出</a>';
		editHTML_SYS=EditHTML;
		 
	 }
		
	 
	 if (itemno_>5)
	 {
	 
	 htmlcode="<tr><td>"+ExportCheckBoxHTML+ShowItemID+"</td><td><a href=\"dev_edit_script.html?id="+encFilename+"\">"+ item[0]+"</a></td><td>"+filename+"</td><td> "+EditHTML+"</td> </tr>\n";
	 }
	 else
	 {
	 htmlcode="<tr><td>"+ExportCheckBoxHTML+ShowItemID+"</td><td><a href=\"dev_edit_script.html?id="+encFilename+"\">"+item[0]+"</a></td><td>"+filename+"</td><td>"+editHTML_SYS+"  </td> </tr>\n";		 
		 
	 }
	 
	 if (AdvEng==0)
	 {
	 DefEngHtml=htmlcode+DefEngHtml;
	 }
	 else
	 {
		AdvEngHtml=htmlcode+AdvEngHtml;			 
	 }
	 
	 if (AppType<6) //myprogram
	 {
		 MyProData=htmlcode+MyProData;
	 }
	 else if (AppType==6) //demo
	 {
		 
		 DemoProData=htmlcode+DemoProData;
	 }
	  else
	  {
		  
		 classProData=htmlcode+classProData 
	  }
	 
	 
	 
	 
	 }
	}
	 htmlcode=" <tr>          <td>?</td>          <td>...</td>          <td>....</td>          <td>....</td>        </tr>";
	if (MyProData.length<20)   {MyProData=htmlcode;}
	if (DemoProData.length<20) {DemoProData=htmlcode;}
	if (classProData.length<20) {classProData=htmlcode;}
	if (DefEngHtml.length<20) {DefEngHtml=htmlcode;}
	if (AdvEngHtml.length<20) {AdvEngHtml=htmlcode;}
	
	$("#TaskDataList").html(MyProData); 
	$("#DemoTaskDataList").html(DemoProData);
	$("#ExtTaskDataList").html(classProData);
	$("#DefEngTaskDataList").html(DefEngHtml);
	$("#AdvEngTaskDataList").html(AdvEngHtml);	
}


function ExtracIRIdx(LineData)
{
	var lines;
	var items;
	var item;
	var i;
	var htmlcode="";
	var itemno_=1;	
	var itemno=0;
	var filename="";
	var encFilename="";
	lines=LineData.split("\n");
	for (i in lines)
	{
	 items=lines[i].split("|");
	 if (typeof(items[1])==="undefined")
	 {
	   
	 }
	 else
	 {
	 item=items[2].split("^");
	 itemno_++;
	 itemno=lines.length-itemno_;
	 filename=items[1];
	 encFilename=encodeURIComponent(filename);
	 htmlcode="<tr><td><i class=\" icon-double-angle-right\"></i> "+itemno+"</td><td>"+filename+"</td><td>IR1.Send(\""+filename+"\"); </td><td> -- </td><td><a href=\"javascript:SendRequest_LearIR('"+encFilename+"');\" class=\"btn btn-primary btn-sm\" ><i class=\"icon-edit\"></i> 重新学习</a>  <a href=\"javascript:SendRequest_DelIRFile('"+filename+"','');\"  class=\"btn btn-danger btn-sm\"><i class=\"icon-trash\"></i> 删除 </a>  <a href=\"javascript:TestIR('"+filename+"','');\"  class=\"btn btn-success btn-sm \"><i class=\"icon-play\"></i> 测试 </a>  </td> </tr>\n"+htmlcode;
	 }
	}
	if (htmlcode.length<20) htmlcode=" <tr>          <td>?</td>          <td>...</td>          <td>....</td>          <td>....</td>        </tr>";
	$("#TaskDataList").html(htmlcode); 
}

function TestIR(code,port)
{
	SendRequest_SaveFile_Debug('IR_Debug.tsk','SetDebugMode(21);  '+'IR1.Send("'+code+'");' ,'');   
}
		   



function RunTask(taskName)
{
SendRequest_sysinfo(taskName);
}

function AddControlButton(taskTitle,taskCode,taskIMG)
{
  var htmlCode='  <div class="col-md-1">';

  htmlCode=htmlCode+'	<div class="hovereffect" onclick="RunTask(\''+taskCode+'\');">';

  htmlCode=htmlCode+'		 <img src="images/'+taskIMG+'" class="img-responsive center-block" >';

  htmlCode=htmlCode+'	 <div class="overlay">';
  htmlCode=htmlCode+'		<h2>'+taskTitle+'</h2>';
  htmlCode=htmlCode+  '</div>	 </div>	 </div>	 ';
  return htmlCode;
  
}

function AddControlButton2(taskTitle,taskCode,taskIMG)
{
  var htmlCode='<li>';

  htmlCode=htmlCode+'<a href="javascript:RunTask(\''+taskCode+'\');" >';

  htmlCode=htmlCode+'<img class="shake" src="images/ctrl/'+taskIMG+'" /><strong>'+taskTitle+'</strong></a>';

  htmlCode=htmlCode+  '</li> ';
  return htmlCode;
  
}


function ExtracIdxToControl(LineData)
{
	var lines;
	var items;
	var item;
	var i;
	var htmlcode="";
	var itemno_=1;	
	var itemno=0;
	var filename="";
	var encFilename="";
	lines=LineData.split("\n");
	for (i in lines)
	{
	 items=lines[i].split("|");
	 if (typeof(items[1])==="undefined")
	 {
	   
	 }
	 else
	 {
	 item=items[2].split("^");
	 itemno_++;
	 itemno=lines.length-itemno_;
	 filename=items[1];
	 encFilename=encodeURIComponent(filename);
	 //htmlcode="<tr><td>"+itemno+"</td><td>"+item[0]+"</td><td>"+filename+"</td><td><a href=\"dev_edit_script.html?id="+encFilename+"\" class=\"btn btn-primary btn-xs\" >Edit</a>  <a href=\"javascript:SendRequest_DelFile('"+filename+"','');\"  class=\"btn btn-danger btn-xs\">Del </a></td> </tr>\n"+htmlcode;
	 
	 if ((item[1]<5 ) &&(itemno_>4))
	 {
		 
		htmlcode=AddControlButton2(item[0],filename,item[2])+htmlcode; //新的UI
	 }
	 //alert(lines);
	 }
	}
	//if (htmlcode.length<20) htmlcode=" <tr>          <td>?</td>          <td>...</td>          <td>....</td>          <td>....</td>        </tr>";
	
	$("#ControlTaskDataList").html(htmlcode); 
	
}



function ViewOfflineIdxData()
{
					var storage=window.localStorage;
				
				var content=storage.getItem("Sim_Index_Db");
				
				if ((content) && (content.length>10))
					ExtracIdx(content);

				
	
}

function ViewOfflineControlData()
{
					var storage=window.localStorage;
				
				var content=storage.getItem("Sim_Index_Db");
				
				if ((content) && (content.length>10))
					ExtracIdxToControl(content);

				
	
}

function ShowStatus(id)
{

	if ($('#connectStataus').length<1) return -1;
	switch(id)
	{
		case 0:
			$('#connectStataus').get(0).className='icon-remove';	// disconnect	
			break;
			
		case 1:
			$('#connectStataus').get(0).className='icon-spinner icon-spin';	 //Login	
			break;
		
		case 2:
			$('#connectStataus').get(0).className='icon-link';	//connected
			break;

		case 3:
			$('#connectStataus').get(0).className='icon-exchange';	//	ready
			break;

		case 4:
			$('#connectStataus').get(0).className='icon-refresh icon-spin';		//exchange data
			break;			
	}





	
}

function ShowInfo_LabelStatus(msg)
{
	if ($('#LabelStatus').length>0)
	{
	$("#LabelStatus").html(" "+msg);
    if ((msg.indexOf('错误') >-1) || ((msg.indexOf('error') >-1) ))	
		$('#LabelStatus').get(0).className='label label-danger';
	else
		$('#LabelStatus').get(0).className='label label-success';
	}
}

function formatDataLen(i)
 {
 var s=i.toString();
   switch (s.length)
   {
   case 1:
     s='0000'+s;
 	break;
   case 2:
 	s='000'+s;
 	break;
   case 3:
 	s='00'+s;
 	break;	
   case 4:
 	s='0'+s;
 	break; 	
   }
   return s;
 }
 
function ShowOfflineAlert()
 {
   //alert("You are offline,now we try to connect the server,please wait");
   ShowMessageBox("Error","You are offline,now we try to connect the server,please wait");
   
 }
 
 
 function SendRequest_LoadIR(pass)
 {
 	if (isWebsocketConnect==false)
 	{
 	WS_Connect();
 	ShowOfflineAlert();
 	return 0;
 	}
 
 	idxfile=Base64_encode("ir.db");
 	
 	var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"AccessToken\":\""+RemoteAccessToken+"\",\"Radmin\":\"TRUE\",\"Action\":\"View\",\"Enc\":\"1\",\"Filename\":\""+idxfile+"\",\"Pass\":\""+pass+"\",\"msg\":\""+idxfile+"\",\"VerID\":\"V2\"}";
 	var jdata=formatDataLen(jsondata.length+5)+jsondata;
 	ws.send(jdata); 
 	log(jdata);
 }
 
 
function SendRequest_sysinfo(pass)
 {
 	if (isWebsocketConnect==false)
 	{
 	WS_Connect();
 	ShowOfflineAlert();
 	return 0;
 	}
 
 	idxfile=Base64_encode("sysinfo");
 	
 	var jsondata="{\"Type\":\"Msg\",\"uType\":\"Msg\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"AccessToken\":\""+RemoteAccessToken+"\",\"Action\":\"sysinfo\",\"Filename\":\""+idxfile+"\",\"msg\":\""+pass+"\",\"VerID\":\"V2\"}";
 	var jdata=formatDataLen(jsondata.length+5)+jsondata;
 	ws.send(jdata); 
 	log(">>"+jdata);
 }
 
function SendRequest_LoadIdx(pass)
 {
 	if (isWebsocketConnect==false)
 	{
 	WS_Connect();
 	ShowOfflineAlert();
 	return 0;
 	}
 
 	idxfile=Base64_encode("index.db");
 	
 	var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"AccessToken\":\""+RemoteAccessToken+"\",\"Radmin\":\"TRUE\",\"Action\":\"View\",\"Enc\":\"1\",\"Filename\":\""+idxfile+"\",\"Pass\":\""+pass+"\",\"msg\":\""+idxfile+"\",\"VerID\":\"V2\"}";
 	var jdata=formatDataLen(jsondata.length+5)+jsondata;
 	ws.send(jdata); 
 	log(jdata);
 }
 
 
 var delCount=0;
 
function SendRequest_DelFile(filename_,pass)
 {
 	if (isWebsocketConnect==false)
 	{
 		WS_Connect();
 		ShowOfflineAlert();
 		return 0;
 	}
	
	var DelConfirm=false;
	
	if (delCount<4)
	{
		
			
		if (confirm("确认要删除["+filename_+"]吗?") == true)	 DelConfirm=true;	
		
		if (delCount==3) 
		{
			if (confirm("AI系统检测到您需要删除多个程序，将不再提醒?") == false)	delCount=0;
			
		}
			
		delCount++;
	}
	else
	{
		DelConfirm=true;		
			
	}
	
	
	
	filename=Base64_encode(filename_); 
 
 	if  (DelConfirm)
 	{
 	var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"Action\":\"Del\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"AccessToken\":\""+RemoteAccessToken+"\",\"Filename\":\""+filename+"\",\"Pass\":\""+upass+"\",\"msg\":\""+filename+"\",\"VerID\":\"V2\"}";
 	var jdata=formatDataLen(jsondata.length+5)+jsondata;
 	ws.send(jdata); 
 	ShowInfo_LabelStatus("File Deleted!"); 	
 	}
 
 }

function SendRequest_DelIRFile(filename_,pass)
{
 	if (isWebsocketConnect==false)
 	{
 		WS_Connect();
 		ShowOfflineAlert();
 		return 0;
 	}
 
 	filename=Base64_encode(filename_); 
 	
 	if(confirm("Are you sure to del this IR?") == true)
 	{
 	var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"Action\":\"IR_Del\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"AccessToken\":\""+RemoteAccessToken+"\",\"Filename\":\""+filename+"\",\"Pass\":\""+upass+"\",\"msg\":\""+filename+"\",\"VerID\":\"V2\"}";
 	var jdata=formatDataLen(jsondata.length+5)+jsondata;
 	ws.send(jdata); 
 	ShowInfo_LabelStatus("File Deleted!"); 	
 	}
}
 
 
function SendRequest_UCI_GET(key,interfc)
{
 	if (isWebsocketConnect==false)
 	{
 		WS_Connect();
 		ShowOfflineAlert();
 		return 0;
 	}
	
	var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"AccessToken\":\""+RemoteAccessToken+"\",\"Action\":\"UCIR\",\"Enc\":\"1\",\"Filename\":\""+interfc+"\",\"Pass\":\""+upass+"\",\"msg\":\""+interfc+"\",\"Key\":\""+Base64_encode(key)+"\",\"interface\":\""+interfc+"\",\"VerID\":\"V2\"}";			
	var jdata=formatDataLen(jsondata.length+5)+jsondata;
	ws.send(jdata); 
	log(jdata);	
			
}

function SendRequest_UCI_SET(key,val,interfc)
{
	if (isWebsocketConnect==false)
	{
	WS_Connect();
	ShowOfflineAlert();
	return 0;
	}
	
	var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"Action\":\"UCIW\",\"Key\":\""+Base64_encode(key)+"\",\"Value\":\""+Base64_encode(val)+"\",\"interface\":\""+interfc+"\",\"user\":\""+uuser+"\",\"Pass\":\""+upass+"\",\"Filename\":\"MTIzNDU2Nzg=\",\"VerID\":\"V2\"}";
	var jdata=formatDataLen(jsondata.length+5)+jsondata;
	ws.send(jdata); 
	log(jdata);	
}

function SendRequest_UCI_SET_ALL(val,interfc)
{
	if (isWebsocketConnect==false)
	{
	WS_Connect();
	ShowOfflineAlert();
	return 0;
	}
	
	var key='-all';
	var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"Action\":\"UCIW\",\"Key\":\""+Base64_encode(key)+"\",\"Value\":\""+Base64_encode(val)+"\",\"interface\":\""+interfc+"\",\"user\":\""+uuser+"\",\"Pass\":\""+upass+"\",\"Filename\":\"MTIzNDU2Nzg=\",\"VerID\":\"V2\"}";
	var jdata=formatDataLen(jsondata.length+5)+jsondata;
	ShowInfo_LabelStatus("正在提交数据....");	
	ws.send(jdata); 
	log(jdata);
	ShowInfo_LabelStatus("正在配置网络....");	
}

function SendRequest_UCI_SET_ALL_ID(val,interfc,configID)
{
	if (isWebsocketConnect==false)
	{
	WS_Connect();
	ShowOfflineAlert();
	return 0;
	}
	
	var key='-all';
	var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"Action\":\"UCIW\",\"Key\":\""+Base64_encode(key)+"\",\"Value\":\""+Base64_encode(val)+"\",\"interface\":\""+interfc+"\",\"user\":\""+uuser+"\",\"Pass\":\""+upass+"\",\"configID\":\""+configID+"\",\"Filename\":\"MTIzNDU2Nzg=\",\"VerID\":\"V2\"}";
	var jdata=formatDataLen(jsondata.length+5)+jsondata;
	ShowInfo_LabelStatus("正在提交数据....");	
	ws.send(jdata); 
	log(jdata);
	ShowInfo_LabelStatus("设备已连接");	
}

function UCI_SetGWIP(iptID)
{
	var gwIP=$("#"+iptID).val();
	
	if (isvalidLANGateWay(gwIP))
	{
		SendRequest_UCI_SET('LAN_IP_ADDR',gwIP,'network');
		ShowInfo_LabelStatus('新的网关已经设置：'+gwIP);
	}
	else
	{
		//$('#'+iptID).get(0).className='form-group has-error';
		ShowInfo_LabelStatus(gwIP+'网关IP格式错误,请参考:192.168.[1-20].1');
		$("#"+iptID).focus();
	}
}
 
 

var log =function(s) {  
 if (document.readyState !== "complete") {  
 	//log.buffer.push(s);  
 } else {  
 	 if ((false) && (document.getElementById("FileContent")))
	{document.getElementById("FileContent").value =s; }// (s + "\n")+document.getElementById("FileContent").innerText; 
 	//console.log(s);
 }  
 } 
 
function GetRandomFileName()
 {
  var ret="";
  var myDate = new Date();
  ret=myDate.getTime();
  ret=ret.toString().slice(-8);
  return ret;
 }
 
function Base64_encode(data)
{
	var bas64=new Base64(); 
	return bas64.encode(data);
}

function Base64_decode(data)
{
	var bas64=new Base64(); 
	return bas64.decode(data);
}
//------------Edit File-------------
function printLog(data,isComp)
{
		//showDebugInfo=false;
		if (isComp) return;
		var time= new Date();
		var timestr= time.getHours()+":"+time.getMinutes()+":"+time.getSeconds();				
		console.log(timestr+" > "+uidata[1]);	
		var tmpstr=$("#LogRes").val();
		if ((tmpstr.length)>4096) tmpstr=tmpstr.substring(0,4096); 
		$("#LogRes").val(timestr+" > "+uidata[1]+'\n'+tmpstr);
}

			//login info
			function On_EditScriptLogin(status)
			{			
					if (status==1)
					{
						log("设备已连接");

						ShowInfo_LabelStatus("设备已连接");
						if (EditFileName !== "") SendRequest_LoadFile(EditFileName,Password);
					}
					else
						log("登录失败，请检查您的用户名和密码!");			

			}
			
			
			
			function On_EditScriptShowFile(Filename_,jdata)
			{
						var bas64=new Base64();	
						var msgFilename=bas64.decode(Filename_);
						
						if ((msgFilename===EditFileName) && (FileEdited===false) )
						{
							var msgFileContent=jdata['Msg'];
							  var IdxContent=jdata['Idx'];
							  msgFileContent=bas64.decode(msgFileContent);
							  IdxContent=bas64.decode(IdxContent);
							  //$("#FileContent").val(msgFileContent);
							  SetFileContent(msgFileContent);
							  $("#FileName").val(msgFilename);	
							  GetCodeEng(msgFilename);
							  //$("#IdxContent").val(IdxContent);	
							  ExtactIdxString(IdxContent);
							  
							  FileEdited=true;
						}				
			
			}
			
			function On_EditScriptShowMessage(jdata)
			{
					var bas64=new Base64();	
				    var message=jdata['Msg'];
					var mtype=jdata['mType'];
					var utype=jdata['uType'];
					
					if (mtype>0)
					{
					message=bas64.decode(message);
					message=message+"\n";
					}
 
					log("收到消息:"+message);
					//alert(message);
					switch	(mtype)
					{
					case 2:
						var lines=message.split("\n");
						for(i=0;i<lines.length-1;i++)
						{ 
							uidata= lines[i].split("|");   
														
							//if ( (!(uidata[0].indexOf("/")>0))   && (!($(uidata[0]).length==0)) )  {log(uidata[0]);$(uidata[0]).html(uidata[1]);}
							if   ( (uidata.length>2) && ((uidata[0].indexOf("/")<0) && ($("#"+uidata[0]).length>0)) )
							{
							var DataShow=uidata[1];
							if (DataShow.length>48) DataShow=DataShow.substr(1,58)+'...';
							
							if ($("#"+uidata[0]).length>0) { $("#"+uidata[0]).html(DataShow);}
							
 
							if (uidata[0]===("LabelCompileLog")) 
							{
							  ShowDebugMsg(uidata[1]);
							}
							
							printLog(uidata[1],uidata[0]===("LabelCompileLog"));
						  }
						}
						break;
					
					case 0:
		
						ShowInfo(message,0);
						break;

					
					
						}	
						
						if (utype=='Info')
						{
							message=bas64.decode(message);
							message=message+"\n";
					
							ShowInfo(message,0);						
							
						}

					 	if (GotoNextPage !=="")
						{
							window.location.href=GotoNextPage;
						}					
			
			}
			
			function ProcessEditScriptMsg(msg)
			{
				
				ShowProcessStatus();	
				jsonstr=msg.substring(5);
				var jdata = eval('(' + jsonstr + ')');	
			    msgType=jdata['Type'];
				switch	(msgType)
				{
				case 'auth' :
					var status=jdata['status']	;
					On_EditScriptLogin(status);
					break;				
				
				case 'Msg'	:
					
					//Show Script content
					msgFilename_=jdata['Filename'];
					if ((msgFilename_) && msgFilename_.length>0)
					{
					  On_EditScriptShowFile(msgFilename_,jdata);
					}
					else
					{
					  On_EditScriptShowMessage(jdata); 
					}
					break;
				}
				
					
				
			}
			function SendRequest_LoadFile(filename_,pass,pt)
			{
				if (isWebsocketConnect==false)
				{
				WS_Connect();
				ShowOfflineAlert();
				return 0;
				}
				
				var bas64=new Base64();	
				filename=bas64.encode(filename_);
				
				
				if (typeof(pt)=="undefined")
					var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"AccessToken\":\""+RemoteAccessToken+"\",\"Action\":\"View\",\"Filename\":\""+filename+"\",\"msg\":\""+filename+"\",\"user\":\""+uuser+"\",\"Pass\":\""+upass+"\",\"Enc\":1,\"VerID\":\"V2\"}";
				else
					var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"AccessToken\":\""+RemoteAccessToken+"\",\"Action\":\"View\",\"Filename\":\""+filename+"\",\"msg\":\""+filename+"\",\"Path\":\""+uuser+"\",\"Pass\":\""+upass+"\",\"Enc\":1,\"VerID\":\"V2\"}";					
				
					
				var jdata=formatDataLen(jsondata.length+5)+jsondata;
				ws.send(jdata); 
				log(jdata);
				//log("");
			}
			
			function SendRequest_SaveFile_Debug(filename_,content,pass)
			{
				var DebugFileName="DebugCode.tsk";
				if (filename_.substr(0,1)==='_') DebugFileName="_DebugCode.tsk";	
				if (filename_.substr(0,2)==='__') DebugFileName="__DebugCode.tsk";						
				if (isWebsocketConnect==false)
				{
					WS_Connect();
					ShowOfflineAlert();
					return 0;
				}
				ShowDebugMsg("UpLoading...");
				GotoNextPage="";
				if (content.length<1) 
				{content="Log(\"Nil\");";}
				else if (content.length>128*1024)
				{
				  alert("Error: The Program Code is  >= 64KB ,Please Try to Divide to 2 apps!");
				  return 0;
				}
				//content=content+"\n SetDebugMode(1);\n";
				content="SetDebugMode(1);"+content;
				var bas64=new Base64();
				var	Base64IdxContent="";			
				Base64Content=bas64.encode(content);
				//Base64IdxContent=bas64.encode(idxLine);
				
				filename=bas64.encode(DebugFileName);
				
				var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"AccessToken\":\""+RemoteAccessToken+"\",\"Action\":\"RunCode\",\"Filename\":\""+filename+"\",\"Idx\":\""+Base64IdxContent+"\",\"Msg\":\""+Base64Content+"\",\"user\":\""+uuser+"\",\"Pass\":\""+upass+"\",\"Enc\":1,\"VerID\":\"V2\"}";
				var jdata=formatDataLen(jsondata.length+5)+jsondata;
				ws.send(jdata); 
				log(jdata);
			}
		
			function SendRequest_SaveFile_Return(filename_,idxLine,content,pass)
			{
				SendRequest_SaveFile(filename_,idxLine,content,pass);
				GotoNextPage="dev_view_script.html";
			}
			
			function SendRequest_SaveFile(filename_,idxLine,content,pass)
			{
				if (isWebsocketConnect==false)
				{
					WS_Connect();
					ShowOfflineAlert();
					return 0;
				}
				
				GotoNextPage="";
				filename_=$.trim(filename_);
				if (filename_.indexOf(".tsk")<0) filename_=filename_+".tsk";
				if (content.length<1) 
				{content="--undefined";}
				else if (content.length>128*1024)
				{
				  alert("Error: The Program Code is  >= 64KB ,Please Try to Divide to 2 apps!");
				  return 0;
				}
				
				var bas64=new Base64();	
				Base64Content=bas64.encode(content);
				Base64IdxContent=bas64.encode(idxLine);
				filename=bas64.encode(filename_);
				
				var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"AccessToken\":\""+RemoteAccessToken+"\",\"Action\":\"Edit\",\"Filename\":\""+filename+"\",\"Idx\":\""+Base64IdxContent+"\",\"Msg\":\""+Base64Content+"\",\"user\":\""+uuser+"\",\"Pass\":\""+upass+"\",\"VerID\":\"V2\"}";
				var jdata=formatDataLen(jsondata.length+5)+jsondata;
				ws.send(jdata); 
				log(jdata);
				//ShowInfo("Save File");							
			}
			
			function SendRequest_LearIR(filename_)
			{
				if (isWebsocketConnect==false)
				{
					WS_Connect();
					ShowOfflineAlert();
					return 0;
				}
				
				
				GotoNextPage="";
				//idxLine==$.trim(ActionTypeID)+","+ActionPara+"|"+$.trim(TaskFileName)+"|"+AliasName+"^"+GroupID+"^"+iconName+"^|"+$.trim(VoicePara)+"|";
				idxLine='0,*|'+filename_+'|'+filename_+'^^^|0|';
				filename_=$.trim(filename_);
				//if (filename_.indexOf(".ir")<0) filename_=filename_+".ir";
				LearnCode='LearnIR("'+filename_+'");';
				
				var bas64=new Base64();	
				Base64Content="";  
				Base64IdxContent=bas64.encode(idxLine);
				filename=bas64.encode(filename_);
				
				var jsondata="{\"Type\":\"Msg\",\"uType\":\"Admin\",\"From\":\""+uuser+"\",\"To\":\""+toRcver+"\",\"AccessToken\":\""+RemoteAccessToken+"\",\"Action\":\"IR_E\",\"Filename\":\""+filename+"\",\"Idx\":\""+Base64IdxContent+"\",\"Msg\":\""+Base64Content+"\",\"user\":\""+uuser+"\",\"Pass\":\""+upass+"\",\"VerID\":\"V2\"}";
				var jdata=formatDataLen(jsondata.length+5)+jsondata;
				ws.send(jdata); 
				log(jdata);
				
				
				setTimeout("SendRequest_SaveFile_Debug('IR_Learn_Debug.tsk',LearnCode,'');",1000);
				
				
				//ShowInfo("Save File");							
			}
			
			function ShowInfo(msg,timeout)
			{
			
			if ($("#StatusBarLabel").length<1) return -1;
			
			 var LabelBar=$("#StatusBarLabel");
			LabelBar.html(msg);	
			$("#StatusBarLabel").show(100);
			setTimeout(function (){$("#StatusBarLabel").slideUp(100)},4000+timeout);
			//$("#StatusBarLabel").slideUp(2000);

			}
			
			function ShowDebugMsg(msg)
			{
			 var time= new Date();
			 var tmpstr="";
			 var chienseMsg="";
			 var timestr= time.getHours()+":"+time.getMinutes()+":"+time.getSeconds();		
		
			 var obj=$("#LabelCompileLog");
 			 
			 obj.removeClass();
			 if (msg.indexOf("Error")>-1)
			 {
				obj.addClass("label label-danger");
				chienseMsg=GetChineseError(msg); //show chinsese errors
			 }
			 else
			 obj.addClass("label label-success");
			if  (msg.length>0)
			{
				
				tmpstr=$("#LogRes").val();
				if  ((!(tmpstr===undefined))  &&  ((tmpstr.length)>4096)) tmpstr=tmpstr.substring(0,4096); 
				
				
				if (chienseMsg.length>0)
				{
				obj.html(chienseMsg);	
				$("#LogRes").val(timestr+" > "+chienseMsg+"\n"+msg+'\n'+tmpstr);	
				}
				else
				{
				obj.html(msg);
				$("#LogRes").val(timestr+" > "+msg+'\n'+tmpstr);	
					
				}
			}
			}
			
			function ShowMessageBox(title,msg)
			{
					
				$("#myModalLabel").html(title);
				$("#myModalContent").html(msg);
				$('#myModal').modal('show');
								
			}
			
			function HideMessageBox()
			{
					
				$('#myModal').modal('hide');
								
			}			
			
 
 
			
			function Request(Para){ 
				var url = location.href;  
				var ParStr = url.substring(url.indexOf("?")+1,url.length).split("&");  
				var ParObj = {}  
				for (i=0; j=ParStr[i]; i++){  
					ParObj[j.substring(0,j.indexOf("=")).toLowerCase()] = j.substring(j.indexOf("=")+1,j.length);  
				}  
				var retV = ParObj[Para.toLowerCase()];  
				if(typeof(retV)=="undefined"){  
					return "";  
				}else{  
					return retV;  
				}  
			}
			
function GenIdxString()
{
  var ActionTypeID,ActionPara,TaskFileName,AliasName,GroupID,iconName,VoicePara,retString;
  ActionPara=$("#TimeControl").val();
  TaskFileName=$("#FileName").val();
  AliasName=$("#AliasName").val();
  GroupID=$("#GroupID").get(0).selectedIndex;
  iconName=$("#ProICON").val();
  VoicePara=$("#VoiceKeyword").val();
  VoicePara=VoicePara.replace(new RegExp('【', 'g'),"[");
  VoicePara=VoicePara.replace(new RegExp('】', 'g'),"]");
  ActionPara=ActionPara.replace(new RegExp('：', 'g'),":");
  
  if (ActionPara.length>10) ActionTypeID=3
  else ActionTypeID=0;
  retString=GenIdxString_(ActionTypeID,ActionPara,TaskFileName,AliasName,GroupID,iconName,VoicePara);
  return  retString;
}			
			
function GenIdxString_(ActionTypeID,ActionPara,TaskFileName,AliasName,GroupID,iconName,VoicePara)
{
 var retString="";
 if (ActionPara.length==0) ActionPara="nil";
 if (AliasName.length==0)  AliasName="undefined";
 if (TaskFileName.indexOf(".tsk")<0) TaskFileName=TaskFileName+".tsk";
 retString=$.trim(ActionTypeID)+","+ActionPara+"|"+$.trim(TaskFileName)+"|"+AliasName+"^"+GroupID+"^"+iconName+"^|"+$.trim(VoicePara)+"|";

 return retString;
}

function ExtactIdxString(idxString)
{

  var items=idxString.split("|");
  
  if (items.length<2) return -1;
  
  var timeStr="";
  var captionAndIcon=items[2].split("^");
  
  if (captionAndIcon.length<2) return -1;
  
  $("#VoiceKeyword").val(items[3]);
  timeStr=items[0].substring(2,items[0].length);
  if (timeStr.length>3)
  {
  $("#TimeControl").val(timeStr);
  }
  $("#AliasName").val(captionAndIcon[0]);
  $("#GroupID").get(0).selectedIndex=captionAndIcon[1];
  $("#ProICON").val(captionAndIcon[2]);
}

function GetCodeEng(filename)
{
  if (filename.substr(0,1)==='_')
	CodeEng=1;
  else
	CodeEng=0;

  $("#CodeMode").get(0).selectedIndex = CodeEng;
}

function ShowMoreOptions()
{
  $('#AdvOptions').slideToggle(800);
  if ($("#badgeMore").html()==="0")
  {
     $("#badgeMore").html("6");
	 $('#ICO_SHOWMORE').get(0).className='icon-chevron-down';
  }
  else	 
  {
	$("#badgeMore").html("0");
	$('#ICO_SHOWMORE').get(0).className='icon-chevron-up';
	
  }
  
}
			
			
function LocalDbGet(item)
{
  var storage = window.localStorage;
  if (storage)
  {
  return storage.getItem(item);
  }
}
function LocalDbSet(item,val)
{

  var storage = window.localStorage;
  if ((storage) && (val.length>0))
  {
	storage.setItem(item,val);

  }
}

function GetFileContent()
{
	var rCode=editor.getValue();
	rCode=encodeAlias(rCode);
	return rCode;
}

function SetFileContent(code)
{
  code=decodeAlias(code);
  editor.setValue(code);
}

function ShowExample(keyword)
{
  if (keyword.length>2)
  {
    ShowInfo(keyword+"(\"提示信息！\");",0);
  }
}
//--timer
function CheckLastMsgSecond()
{
  var nowtime=new Date(); 
  var OverSeconds=0;
  OverSeconds=(nowtime.getTime()-LastMsgDate.getTime())/1000;
  ShowInfo_LabelStatus(OverSeconds+"秒 前更新");
}

function isvalidIP(ip)  
{   
  var exp=/^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-4])$/;  
  var reg = ip.match(exp);  
  return (reg!==null);
}

function isvalidLANGateWay(ip)  
{   
  if (isvalidIP(ip))
  {
   var item=ip.split(".");
   return ((item[0]=='192') && (item[1]=='168') && (item[2]<21) && (item[3]==1) );
  }
  else
  return (false);
}
		 
function GetrandomString(len) {
　　len = len || 12;
　　var $chars = 'ABCDEFGHJKLMNPQRSTWXYZabcdefhijklmnprstwxyz012345678'; 
　　var maxPos = $chars.length;
　　var ret = '';
　　for (i = 0; i < len; i++) {
        ret += $chars.charAt(Math.floor(Math.random() * maxPos));
　　}

　　return ret;
}

function CreatTokenStr(host,port,id,pass,rcver,tokens)
{
	var str=id+":"+pass+"|"+host+":"+port+"|"+rcver+"|"+tokens;
	return Base64_encode(str);
	
}


function ShowProcessStatus(interval)
{
	var inter= interval || 2000;
	TickCount=0;
	
	if (!myTick)
	{
		myTick=setInterval(sysTickCount,inter);
	
		ShowStatus(4);

	}
	
	
}

function closeSysTick()
{
	if (myTick) {clearInterval(myTick); myTick=null;}	
}

function resetTickCount()
{
	
	TickCount=0;

}

function sysTickCount()
{
	

	
	if (TickCount>0)
	{	
		ShowStatus(3);
		TickCount=0;
		closeSysTick();
	}	
	TickCount++;
	
}

function DrawLineChart(ctx,datas)
{
	return ;
}

function SavedrawHomeLines(key,value)
{
	return ;
}

function drawHomeLines()
{
	return ;
}

function UCI_SimConfig(id)
{
	var mydata={};

	mydata["SimConfigID"]=id;
 
	var jdata=JSON.stringify(mydata);	
 
	SendRequest_UCI_SET_ALL_ID(jdata,'application',id);		
				
			
}

var focusTimer; 
var winLostFocus=0;
window.onblur = function(e){
	
	winLostFocus=1;
 	focusTimer=setTimeout("WinLostFocusTimeout();",30*1000);
 
}
window.onfocus = function(e){
	
	if (winLostFocus>0) clearTimeout(focusTimer);
	
	
	if ((winLostFocus>1) &&  (! isWebsocketConnect) ) WS_Connect();
	
	winLostFocus=0;
	
}

function WinLostFocusTimeout()
{
	if (winLostFocus>0)
	{
		winLostFocus=2;
		if (isWebsocketConnect)  ws.close();
	}
	
}






			
//----------------------------------


!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):"object"==typeof exports?a(require("jquery")):a(jQuery)}(function(a){function b(a){return h.raw?a:encodeURIComponent(a)}function c(a){return h.raw?a:decodeURIComponent(a)}function d(a){return b(h.json?JSON.stringify(a):String(a))}function e(a){0===a.indexOf('"')&&(a=a.slice(1,-1).replace(/\\"/g,'"').replace(/\\\\/g,"\\"));try{return a=decodeURIComponent(a.replace(g," ")),h.json?JSON.parse(a):a}catch(b){}}function f(b,c){var d=h.raw?b:e(b);return a.isFunction(c)?c(d):d}var g=/\+/g,h=a.cookie=function(e,g,i){if(void 0!==g&&!a.isFunction(g)){if(i=a.extend({},h.defaults,i),"number"==typeof i.expires){var j=i.expires,k=i.expires=new Date;k.setTime(+k+864e5*j)}return document.cookie=[b(e),"=",d(g),i.expires?"; expires="+i.expires.toUTCString():"",i.path?"; path="+i.path:"",i.domain?"; domain="+i.domain:"",i.secure?"; secure":""].join("")}for(var l=e?void 0:{},m=document.cookie?document.cookie.split("; "):[],n=0,o=m.length;o>n;n++){var p=m[n].split("="),q=c(p.shift()),r=p.join("=");if(e&&e===q){l=f(r,g);break}e||void 0===(r=f(r))||(l[q]=r)}return l};h.defaults={},a.removeCookie=function(b,c){return void 0===a.cookie(b)?!1:(a.cookie(b,"",a.extend({},c,{expires:-1})),!a.cookie(b))}});
 