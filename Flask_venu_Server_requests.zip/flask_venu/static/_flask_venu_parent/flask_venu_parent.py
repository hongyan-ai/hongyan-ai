from flask import Flask
import os,re,io,sys,time
from datetime import datetime
import threading

class parent_chaosong(object):  # -->None
    def __init__(self,parent = None):
        super().__init__(self,parent)
        
        # Flask use 使用 多界面调用 并进行局域网访问
    @staticmethod  # 起始接口 入参
    def run():
        sound = ""
        demo = ""
    print("多态继承")   
    def flask_ve(self):
        # 守护
        self.pycome_da = ""
        self.linksouden = ""

# 多线程开启 每一个界面 多态flask调用  __name__关闭对
# threading # pyside6
# #   -*- utf-8 -*-

app = Flask(__name__)