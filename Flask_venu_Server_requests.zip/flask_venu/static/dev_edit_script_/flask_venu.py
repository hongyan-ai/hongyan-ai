import serial
from flask import Flask, render_template

app = Flask(__name__,template_folder="D:\\New_Web_code\\code_widget")

@app.route('/')
def index():
    return render_template('dev_edit_script.html')

@app.route('/')
def index1():
    pass

@app.route('/')
def index2():
    pass

@app.route('/')
def index3():
    pass

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
    # 同wifi下 局域网内
