   function $my(id) {return document.getElementById(id);}
   //function $F(name){return document.getElementsByTagName(name);}
   var _funname="sleep";
   
var database = new Array(   
  'sleep`_s`秒(0-65535)`时长`用于系统暂停 延时,delay`sleep(?1) ; --延时?1秒',
   'usleep`_us`微秒(0-65535)`时长`用于系统暂停 延时,delay`usleep(?1) ; --延时?1 us',   
   'msleep`_ms`毫秒(0-65535)`时长`用于系统暂停 延时,delay`msleep(?1) ; --延时?1 ms',
   'beep`_ms`毫秒(0-65535)`时长`系统蜂鸣器,beep`beep(?1) ; --蜂鸣器-笛声时长?1 ms',  
   'print`Message`信息`内容`显示用户信息,用于Debug`print(?1) --显示调试信息`',
   'tcp.send`IP,_Port,Message`IP(192.168.1.130)~1-65535~Msg~`对方IP~对方端口~数据`用于向目标电脑或者设备发送tcp数据` --向?1:?2发送数据:?3 !@ tcp.send(?1,?2,?3); ',
   'tcp.sendhex`IP,_Port,Message`IP(192.168.1.130)~1-65535~Msg~`对方IP~对方端口~16进数据`用于向目标电脑或者设备发送tcp数据` --向?1:?2发送数据:?3 !@ tcp.sendhex(?1,?2,?3); ',   
   'udp.send`IP,_Port,Message`IP(192.168.1.130)~1-65535~Msg~`对方IP~对方端口~传输数据`用于向目标电脑或者设备发送udp数据` --向?1:?2发送数据:?3 !@ udp.send(?1,?2,?3); ',
   'udp.sendhex`IP,_Port,Message`IP(192.168.1.130)~1-65535~Msg~`对方IP~对方端口~16进数据`用于向目标电脑或者设备发送udp数据` --向?1:?2发送数据:?3 !@ udp.sendhex(?1,?2,?3); ',   
   'touch.send`UI_Name,Caption,_alpha`String~String~0-10`对象名称~标题~透明度`更改触摸屏按钮状态', 
   'touch.sendPre`UI_Name,Caption,_alpha`String~String~0-10`对象名称~标题~透明度`预存数据用于返回给触摸屏', 
    'touch.remove`Name`触摸屏按钮`对象名称`取消更新触摸屏数据`touch.remove(?1) ; --不更新?1触摸数据`',    
    'touch.disable`Name`按钮名称`对象名称`禁用触摸屏按钮`touch.disable(?1) ; --禁用触摸屏?1按钮`',    	  
    'touch.enable`Name`按钮名称`对象名称`启用触摸屏按钮`touch.enable(?1) ; --启用触摸屏?1按钮`',    	       
	'touch.speak`TTS`语音播报`文字`触摸屏播放语音TTS`touch.speak(?1) ; --向触摸屏发送语音提示`', 
    'touch.open`Name`xxx.ui`页面名称`启用触摸屏按钮`touch.open(?1) ; --触摸屏切换页面到?1`', 	
    'call`Task`xxx.tsk`控制代码`调用程序(在新线程调用,不阻塞)`call(?1) ; --在新线程不阻塞调用?1`', 	  
    'call_in`Task`xxx.tsk`控制代码`调用程序(线程内调用,阻塞)`call_in(?1) ; --阻塞调用?1`', 	  
	  
   'com?.set`_com_,_Rate_,_DataBit_,_Par_,_StopBit_`com1,com2,com3,com4,com5,com6,com7,com8~9600,2400,4800,9600,19200,38400,57600,115200,921600~8,5,6,7~n,o,e~1,1.5,2`串口号~波特率~数据位~校验位~停止位`设置串口波特率,校验位,停止位,串口设置,set`?1.set(?2,?3,"?4",?5); --设置?1的波特率为?2',
   'IR?.send`_Port_,Key`IR1,IR2,IR3,IR4,IR5,IR6,IR7,IR8~(-需先<a href="dev_IR.aspx" target="_blank">学习</a>)`红外端口~按键名称`红外发送IR?.send`?1.send(?2); --通过端口?1发送按键:?2',
   'com?.send`_com_,_Rate_,_DataBit_,_Par_,_StopBit_,Data`com1,com2,com3,com4,com5,com6,com7,com8~9600,2400,4800,9600,19200,38400,57600,115200,921600~8,5,6,7~n,o,e~1,1.5,2~结束符用 \\n 表示`串口号~波特率~数据位~校验位~停止位~ASCII数据`设置串口波特率并发送ASCII数据,串口发送`?1.set(?2,?3,"?4",?5); --设置?1的波特率为?2 !@?1.send(?6); --发送ASCII数据到?1 ',
   'com?.sendhex`_com_,_Rate_,_DataBit_,_Par_,_StopBit_,Data`com1,com2,com3,com4,com5,com6,com7,com8~9600,2400,4800,9600,19200,38400,57600,115200,921600~8,5,6,7~n,o,e~1,1.5,2~16进数,如:A0 F1 2A`串口号~波特率~数据位~校验位~停止位~16进制`设置串口波特率并发送16进制数据,串口发送`?1.set(?2,?3,"?4",?5); --设置?1的波特率为?2 !@?1.sendhex(?6); --发送16进制hex数据到?1 ',
   'sp8`_Port_,_PowerPort_,_on-off_`com1,com2,com3,com4,com5,com6,com7,com8~1,2,3,4,5,6,7,8,All~on,off~`串口~电源口~动作`电源控制器SP8`?1.set(9600,8,"n",1);!@?1.SP8.Line?2.?3;  --设置?1上的SP8第?2路电源为?3',   
    'sp82`_Port_,_PowerPort_,_on-off_`com1,com2,com3,com4,com5,com6,com7,com8~1,2,3,4,5,6,7,8,All~on,off~`串口~电源口~动作`电源控制器SP82`?1.set(115200,8,"n",1);!@?1.SP82.Line?2.?3;  --设置?1上的SP82第?2路电源为?3',    
   'bus.sp4`_DevID,_PowerPort_,_on-off_`0xff~1,2,3,4,0xff~1,0~`设备ID~电源口~动作`智能空开,电源控制器SP4,0xff代表全部通道`bus.sp4.send(?1,?2,?3);  --设置总线上ID为?1的SP4第?2路电源为?3',   
   'return`__`0,1`是否生效`用于终止当前脚本,quit,return,exit`return(?1) ; -- 退出当前脚本',
   'im.send`Receiver,Message`yourname@jabber.org~~`收件人~内容`发送IM/MQTT信息',
   'wx.send`ID,data`~~~`微信ID~通知内容`发送微信通知,关注公众号[深克斯SimFAS],发送id获取自己id',  
   'time.limit`_h`小时(0-65535)`限制时间`用于限制时间使用`time.limit(?1) ; --系统使用?1小时后,后面代码不再执行',
   'pjlink.on`IP,Pass`投影机IP地址~(可选)`地址~密码`pjlink投影机开机,打开投影机`--通过pjlink打开IP为?1的投影机!@pjlink.on(?1,?2) ; ',  
   'pjlink.off`IP,Pass`投影机IP地址~(可选)`地址~密码`pjlink投影机关机,关闭投影机`--通过pjlink关闭IP为?1的投影机!@pjlink.off(?1,?2) ; ',     
     
    'player.open`IP,File`192.168.20.x~含后缀~`地址~文件名`SimPlayer播放视频,PPT`--播放器?1打开视频?2!@player.open(?1,?2) ;',
    'player.pause`IP`电脑IP`地址`SimPlayer暂停播放`--播放器?1暂停播放视频!@player.pause(?1) ; ',   	
    'player.play`IP`电脑IP`地址`SimPlayer继续播放视频`--播放器?1暂停播放视频!@player.play(?1) ; ',  
    'player.stop`IP`电脑IP`地址`SimPlayer继续播放视频`--播放器?1停止播放视频!@player.stop(?1) ; ',  
    'player.setVol`IP,Value`*192.168.20.x~0-100的值/+n/-n~~`地址~值`调节播放器音量大小`--设置播放器?1的音量?2!@player.setVol(?1,?2) ; ' ,
   
   'pc.wakeup`IP,Mac`192.168.20.255~11:22:33:44:55:66~~`网段~地址`电脑网络唤醒,IP填广播地址`--唤醒网段?1(该IP必须为广播地址)内的?2电脑!@pc.wakeup(?1,?2) ; ',      
   'pc.shutdown`PC-ID`电脑ID`电脑标识`远程关闭电脑,关机,Power off,*代表所有电脑`pc.shutdown(?1) ; --关闭ID为?1的电脑',
   'pc.setVol`ID,Value`*代表所有电脑~0-100的值/+n/-n~~`电脑ID~值`调节电脑音量大小,电脑需先打开SimCTRL`--调整电脑(?1)音量为?2!@pc.setVol(?1,?2) ; ' 
   
   
);  

var ie4;
 
var ns6;

var crossobj;


String.prototype.replaceAll = function(oldStr,newStr) {   
 
     var s=this;  
     while( s.indexOf(oldStr) != -1 ) {  
 
          s=s.replace(oldStr,newStr);   
 
     };  
 
     return s;  
 
 } 
 
 
function SearchFun(txt)
{
	if (txt == null)
	{
	    selectBox.length=0;
		document.getElementById("CodeArea").innerHTML="";
		
		return;
	}
	data_tips="";
	database.sort();
	var hasKeyword;
 
	var selectBox = $my('FunSelBox');
	if (selectBox===null) return;

	selectBox.length=0;
  //alert(myhint.length);	
	 for(var i=0; i<database.length; i++){
			if (txt.length>=2)
			hasKeyword=database[i].toLowerCase().indexOf(txt.toLowerCase()) >= 0;
			else
			hasKeyword=database[i].toLowerCase().indexOf(txt.toLowerCase()) == 0;
	
            if(hasKeyword){
               // alert(database.length);
                data_tips=data_tips+database[i]+"<br>";
				var para_valueof=database[i];
				var arr_para_valueof=para_valueof.split("`");				
				var caption=arr_para_valueof[0];
				if (caption !='')		
				{		
				//alert(caption);
				
				selectBox.options[selectBox.length]=new Option(caption,i);
				var lastID=i;
				//selectBox.length=selectBox.length+1;
				}
		   //setNames(inputValue, suggest);
            }
 
	 }
  		//document.getElementById("CodeArea").innerHTML=data_tips;
		if (selectBox.length == 1) creatUI(lastID);
		return;      
}
 
 
   
function creatUI(id)
{
  var para_str;
  var para_caption;
  var para_value;
  var para_desc;
  var valueTypeMust=""; //1字符必要型，2数字必要性 ，3字符非必要，4数字非必要
  var firstTag,LastTag;
  var CodeArea=document.getElementById("CodeArea");
  var MutiCode;
  var i;
  del();
  funstr=database[id];
  spValue=funstr.split("`");
  
  $my("txtIPT_FunName").value=spValue[0];
  $my("FunDesc").innerHTML=spValue[4];
 
  
  para_str=spValue[1];
  para_valueof=spValue[2];
  para_descof=spValue[3];
  
  MutiCode=spValue[5];
  
  if   (MutiCode !=null)
  { 
    var mytextarea = document.getElementById("txtIPT_MutiCode");
	mytextarea.value=MutiCode;
	//alert(MutiCode);
  }
  
  CodeArea.innerHTML=spValue[0]+'('+para_str+')' + '//'+ spValue[4];
  
  arr_para=para_str.split(",");
  arr_para_valueof=para_valueof.split("~");
  arr_para_descof=para_descof.split("~");
  arr_para_len=arr_para.length;
  
  document.getElementById("ParaLen").value=arr_para_len;
 
  for (i=0;i<arr_para_len;i++)
  {
  
	firstTag= arr_para[i].substr(0,1);
	LastTag= arr_para[i].substr(arr_para[i].length-1,1);
    valueTypeMust="1";
    if ((firstTag != '_') & (LastTag !='_'))  
	 {
	 valueTypeMust="1";
	 }
	 
    else if ((firstTag=='_') & (LastTag !='_'))  //num must
	 {
	   valueTypeMust="2";
	 } 
	else if ((firstTag=='_') & (LastTag =='_')) //num non-must
	 {
	  valueTypeMust="4";
	 }
	else if ((firstTag!='_') & (LastTag =='_'))  
	 {
	 valueTypeMust="3";
	 }
 
	 
	add(arr_para[i],arr_para_valueof[i],arr_para_descof[i],valueTypeMust);
	 //alert(para_str);
  }
   saveAutoCode();
   //document.getElementsByName("txtIPT_ValueType").value=valueTypeMust;
}
 
 
   
function add(caption,value,desc,valueTypeMust){
	var rowslen=document.getElementById("tab").rows.length;
    var otr = document.getElementById("tab").insertRow(-1);
   var checkTd=document.createElement("td");
 
   checkTd.innerHTML = rowslen;
   var otd1 = document.createElement("td");
   otd1.innerHTML = caption.replaceAll('_','') +'('+desc+')<input type="hidden" class="txt" name="infoName_txt" id="infoName_txt'+($my('tab').rows.length-1)+'" maxlength="255" value="'+valueTypeMust+'" />';;
   var otd2 = document.createElement("td");
   var j;
   if (valueTypeMust >2)
   {
    var HtmlValue="\n";
	var optValue;
	
	var Array_value_par=value.split(",");
    for (j=0;j<Array_value_par.length;j++) //Select Box
	{
	 optValue=Array_value_par[j];
	 if (optValue!=null)  HtmlValue=HtmlValue+'<option value="'+optValue+'">'+optValue+'</option> \n';
	}
	
	otd2.innerHTML = '<select name="infoValue_txt" id="infoValue_txt'+($my('tab').rows.length-1)+'"  onChange="saveAutoCode()"/>'+HtmlValue+'</select>'+value.substr(0,30)+'..';   
    //alert(otd2.innerHTML);
   }
   else
   {
	otd2.innerHTML = '<input type="text" class="txt" name="infoValue_txt" id="infoValue_txt'+($my('tab').rows.length-1)+'" maxlength="255" value="" onChange="saveAutoCode()" onKeyUP="saveAutoCode()"/>'+value.substr(0,30)+'..';
   }
 
   otr.appendChild(checkTd);
   otr.appendChild(otd1); 
   otr.appendChild(otd2); 
}
 
 
function add__(){
	var rowslen=document.getElementById("tab").rows.length;
    var otr = document.getElementById("tab").insertRow(-1);
   var checkTd=document.createElement("td");
   checkTd.innerHTML = '<input type="checkbox" class="check" onclick="ccolor()" name="checkItem">';
   var otd1 = document.createElement("td");
   otd1.innerHTML = '<input type="text" class="txt" name="infoName_txt" id="infoName_txt'+($my('tab').rows.length-1)+'" maxlength="255" value=""/>';
   var otd2 = document.createElement("td");
   otd2.innerHTML = '<input type="text" class="txt" name="infoValue_txt" id="infoValue_txt'+($my('tab').rows.length-1)+'" maxlength="255" value=""/>';
 
   otr.appendChild(checkTd);
   otr.appendChild(otd1); 
   otr.appendChild(otd2); 
}
function ccolor()
{
    var c1 = document.getElementsByName('checkItem');
    for(var i=0; i<c1.length; i++)
    if(c1[i].checked)
    {
     c1[i].parentNode.parentNode.className="checkBg";
     c1[i].parentNode.nextSibling.firstChild.className="checkTxt";
     c1[i].parentNode.nextSibling.nextSibling.firstChild.className="checkTxt";
    }
    else { c1[i].parentNode.parentNode.className="";
    c1[i].parentNode.nextSibling.firstChild.className="";
     c1[i].parentNode.nextSibling.nextSibling.firstChild.className="";}
}
 
function del()
{
   var itemCount=$my("ParaLen").value;
   document.getElementById("ParaLen").value=0;
   var mytextarea = $my("txtIPT_MutiCode");
   mytextarea.value='';
   $my("txtIPU_ResultCode").value='';
 

   if (itemCount == null) return;
   var rowslen=document.getElementById("tab").rows.length;
   if (rowslen<=1) return;
   for(j=0;j<itemCount;j++)
   {
    document.getElementById("tab").deleteRow(1);
   }
   
   
}
 
function del__(){
   var c = document.getElementsByName('checkItem');
   var idArray = new Array();
   for(var i=0; i<c.length; i++)
   if(c[i].checked)
   idArray.push(i);
   var rowIndex;
   var nextDiff =0;
   for(j=0;j< idArray.length;j++)
   {
    rowIndex = idArray[j]+1-nextDiff++;
    document.getElementById("tab").deleteRow(rowIndex);
   }
   }
   
function HideAutoCodeWin(){

if (!crossobj) return;

if (ie4||ns6)
 
crossobj.style.visibility="hidden"
 
else if (ns4)
 
crossobj.visibility="hide"

hideToolTip();
}   
function ShowAutoCodeWin(keyw){

if (ie4||ns6)
 
crossobj.style.visibility="visible"
 
else if (ns4)
 
crossobj.visibility="show";

var KeyWordsIPTBox=$my("Fun_Keywords");
$("#Fun_Keywords").val(keyw);
KeyWordsIPTBox.focus();

//ShowInputTips(KeyWordsIPTBox,TipsTitle);

window.setTimeout("hideToolTip()",5000);

}  


   


   
 //Append The Result Code To the WorkAear  
function SaveToWorkArea(codestr)
{
//var CodeArea=$my("filecontent");
//	if (CodeArea) CodeArea.value+='\n'+codestr;

 var codestr=editor.getValue()+'\n'+codestr;
 editor.setValue(codestr);


}   


function saveAutoCode(){

    //var postString = $my("postString");
	 var mytextarea = $my("txtIPT_MutiCode");
     //var checkboxs = document.getElementsByName("checkItem");
     var ttab = document.getElementsByName("infoName_txt");
     var tt2 = document.getElementsByName("infoValue_txt");
	 var CodeArea=document.getElementById("CodeArea");
     var _funname="?";
	 var valueTypeMust=  document.getElementsByName("txtIPT_ValueType").value;
	 var valueType;
     var idArray = new Array();
	 var ReturnCodeString;
     var MutiCode;
     var itemCount=$my("ParaLen").value;
     if (itemCount == null) return;
  
     for(i=0;i<itemCount;i++)
    {
	 valueType=ttab[i].value;
     if ((valueType == "1") || (valueType == "3"))
	  {
	   idArray.push('"'+tt2[i].value+'"'  ); 
	  }
    else
	  {
	  idArray.push(tt2[i].value  );
	  }
    }
       
	MutiCode=mytextarea.value;
	
	if (MutiCode.length<5)
	{
	//普通函数
    _funname=$my("txtIPT_FunName").value;
    ReturnCodeString =_funname+"("+ idArray.join(",")+")";
	}
	else
	{
	     for(i=1;i<idArray.length+1;i++)
		 {
		 var newstr=idArray[i-1];
 
		 if (newstr != '') MutiCode=MutiCode.replaceAll('?'+i,newstr);		 
		 }
		 ReturnCodeString=MutiCode;
	}
    $my("txtIPU_ResultCode").value=ReturnCodeString.replaceAll("!@",'\n');
	//postString.value=ReturnCodeString;	  
	CodeArea.innerHTML =ReturnCodeString.replace(/!@/g,'<br>');   // 
	
}
 
function SaveToClip()
{
	var ResultStr=$my("txtIPU_ResultCode").value;
	if (clipboardData)
	clipboardData.setData("Text",ResultStr);
 
}
 
function AddToMain()
{
	var ResultStr=$my("txtIPU_ResultCode").value;
	SaveToWorkArea(ResultStr);
 
}
 
function alldell()
   {
   var des =document.getElementsByName('checkItem');
   for(var i=0;i<des.length;i++)
   {
    if(des[i].checked=document.getElementById('delall').checked){
    des[i].parentNode.parentNode.className="checkBg";
    des[i].parentNode.nextSibling.firstChild.className="checkTxt";
    des[i].parentNode.nextSibling.nextSibling.firstChild.className="checkTxt";}
    else{ des[i].parentNode.parentNode.className="";
     des[i].parentNode.nextSibling.firstChild.className="";
     des[i].parentNode.nextSibling.nextSibling.firstChild.className="";}
   }
   } 

function autoCodeINI()
{
 ie4=document.all;//IE4+
 
 ns6=document.getElementById&&!document.all;//ns6
 
 crossobj=ns6? document.getElementById("AutoCodeArea") : document.all.AutoCodeArea;


SearchFun('');
HideAutoCodeWin();


}

/*
TipBox
*/
function showToolTip(e,text){
	if(document.all)e = event;
	
	var obj = document.getElementById('bubble_tooltip');
	var obj2 = document.getElementById('bubble_tooltip_content');
	obj2.innerHTML = text;
	obj.style.display = 'block';
	var st = Math.max(document.body.scrollTop,document.documentElement.scrollTop);
	if(navigator.userAgent.toLowerCase().indexOf('safari')>=0)st=0; 
	var leftPos = e.clientX - 100;
	if(leftPos<0)leftPos = 0;
	obj.style.left = leftPos + 'px';
	obj.style.top = e.clientY - obj.offsetHeight -35 + st + 'px';
}	
//Show The Tips Box near the object(input...)
function ShowInputTips(from,text){

	if (from == null) return;
	var obj = document.getElementById('bubble_tooltip');
	var obj2 = document.getElementById('bubble_tooltip_content');
	obj2.innerHTML = text;
	obj.style.display = 'block';

	obj.style.left = (getAbsLeft(from)-80) + 'px';
	obj.style.top = (getAbsTop(from) - 98) +  'px';
	
	window.setTimeout("hideToolTip()",6000);
	
}

function ShowInputTipsTop(from,text){

	if (from == null) return;
	var obj = document.getElementById('bubble_tooltip');
	var obj2 = document.getElementById('bubble_tooltip_content_top');
	obj2.innerHTML = text;
	obj.style.display = 'block';

	obj.style.left = (getAbsLeft(from)+40) + 'px';
	obj.style.top = (getAbsTop(from) +95) +  'px';
	
	window.setTimeout("hideToolTip()",6000);
	
}


   function getAbsLeft(e){
     var l=e.offsetLeft; 
     while(e=e.offsetParent)  l += e.offsetLeft; 
     return l;
   }
   function getAbsTop(e) {
     var t=e.offsetTop;  
     while(e=e.offsetParent)  t += e.offsetTop;  
     return t;
   }



function hideToolTip()
{
	document.getElementById('bubble_tooltip').style.display = 'none';
	
}

//Move the DIV


function drag_drop(e){

    //alert(crossobj);
	if (ie4&&drag){
	
		crossobj.style.left=tempx+event.clientX-offsetx

		crossobj.style.top=tempy+event.clientY-offsety
		
		return false
	}

	else if (ns6&&drag){

		crossobj.style.left=tempx+e.clientX-offsetx
		
		crossobj.style.top=tempy+e.clientY-offsety
		
		return false
	}
}




function initializedrag(e){

	if (ie4&&event.srcElement.id==CanMoveID||ns6&&e.target.id==CanMoveID){

		offsetx=ie4? event.clientX : e.clientX

		offsety=ie4? event.clientY : e.clientY

		tempx=parseInt(crossobj.style.left)

		tempy=parseInt(crossobj.style.top)

		drag=true

		document.onmousemove=drag_drop
		//alert("move ini done!")
	}
}

function iniDivMove(){

	
	document.onmousedown=initializedrag
	
	document.onmouseup=new Function("drag=false")	
}

