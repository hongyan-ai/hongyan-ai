// CodeMirror, copyright (c) by Marijn Haverbeke and others

  var BuildinString= ("_G _VERSION assert require load " +
    "select tonumber tostring type unpack print printhex " +
    "math.abs math.acos math.asin math.atan math.atan2 math.ceil math.cos math.cosh math.deg " +
    "math.exp math.floor math.fmod math.frexp math.huge math.ldexp math.log math.log10 math.max " +
    "math.min math.modf math.pi math.pow math.rad math.random math.randomseed math.sin math.sinh " +
    "math.sqrt math.tan math.tanh simfas simfas.com simfas.cn " +
	"date.getTime date.getMonth date.getYear date.getDay date.getHour date.getMinute date.getSecond date.getWeek " +
    "string.byte string.char string.dump string.find string.format string.gmatch string.gsub " +
    "string.len string.lower string.match string.rep string.reverse string.sub string.upper string.hexcmp " +
    "table.concat table.joint table.insert table.maxn table.remove table.sort " +
    "crc32 quit getAppPath console email.send im.send ping gethostbyname crc16.toint crc16.tochar " +
	"bus.sp4.send bus.sp4.rs485.send  bus.sp4.rs485.set rs485.open rs485.close rs485.set rs485.send rs485.sendhex bus.sp4.setID relay.set com.sendhex com.send com.set " +
    "beep tcp.send tcp.sendhex tcp.setTimeout udp.send udp.sendhex udp.broadcast touch.send touch.sendPre touch.sendOnce touch.remove touch.keep call  call_in getbit self.checkRunning self.free self.running verMan.core verMan.std " +
	 "touch.enable touch.disable touch.speak touch.open touch.setAngle getKV setKV mqttc_sub  mqttc_pub poll  readfile free  artnet.send setBuffer getBuffer delBuffer getFreeBuffer " +	
	"request self.url self.name self.num self.val self.d1 self.s1 self.id self.k self.v string.bytes string.split string.chars string.trim string.tohex string.tobin string.random tochars import include " + //3rd kwds
    "loadResource loadAsset loadImage ShowMessage SendToTouch SendTCP SendUDP sleep usleep msleep pc.shutdownall pc.shutdown pc.reboot pc.open pc.shell pc.wakeup network.start_http_server network.start_tcp_server network.start_udp_server  network.start_mqtt_server network.start_mqtt_cli "+
	"com1.set com1.send com1.sendhex com2.set com2.send com2.sendhex com3.set com3.send com3.sendhex com4.set com4.send com4.sendhex com5.set com5.send com5.sendhex com6.set com6.send com6.sendhex com7.set com7.send com7.sendhex com8.set com8.send com8.sendhex " +
	"ir1.send ir2.send ir3.send ir4.send ir5.send ir6.send ir7.send ir8.send pc.on pc.off pc.setVol pjlink.on pjlink.off pjlink.check player.open player.play player.pause player.stop player.setVol  modbus.new " +	
	"time.limit tcp.timeout tcp.connect tcp.receive tcp.close tcp.send1 tcp.sendhex1 exitIfr http.get http.post pc.SendKey pc.close pjlink.get pjlink.set tcp.new tcp.sendto tcp.recv tcp.sendrcv tcp.sendhexrcv math.add math.take math.times math.div math.divf str.cmp str.contain str.new  "+
	 "str.cat str.len str.indexof  str.tochar str.sub str.md5 str.sprintf str.Before str.After str.EncodeURL str.EncURL str.setchar str.charAt str.getChar str.getBit sys.uptime sys.now log.save sys.set sys.info sys.ver mqtt.send mqtt.pub " +	
	"system.all system.bus system.ir system.relay system.chinese system.base64  system.info  system.tcp osc.send app.info "
	
	);
  
  var builtinWords = BuildinString.split(" ");
	
// Distributed under an MIT license: http://codemirror.net/LICENSE

(function(mod) {
  if (typeof exports == "object" && typeof module == "object") // CommonJS
    mod(require("../../lib/codemirror"));
  else if (typeof define == "function" && define.amd) // AMD
    define(["../../lib/codemirror"], mod);
  else // Plain browser env
    mod(CodeMirror);
})(function(CodeMirror) {
  var Pos = CodeMirror.Pos;

  function forEach(arr, f) {
    for (var i = 0, e = arr.length; i < e; ++i) f(arr[i]);
  }
  
  function arrayContains(arr, item) {
    if (!Array.prototype.indexOf) {
      var i = arr.length;
      while (i--) {
        if (arr[i] === item) {
          return true;
        }
      }
      return false;
    }
    return arr.indexOf(item) != -1;
  }


  var types =  ("sBus Camera " +
    " MyBit").split(" ");

  var typesQualifiers =  ("local global" ).split(" ");
  var preProcessor =  ("#define #undef #if #ifdef #ifndef #else #elif #endif #error #pragma #line #version #extension" ).split(" ");

  var keywords = ("and break elseif false nil not or return " +
    "true function end if then else do " +
    "while repeat until for in local " +
    "function if repeat do " +
    "end until " ).split(" ");
	
   var builtins=builtinWords;

  function scriptHint(editor, getToken, options) {
    // Find the token at the cursor
    var cur = editor.getCursor(), token = getToken(editor, cur), tprop = token;
    // If it's not a 'word-style' token, ignore the token.
		/*if (!/^[\w$_]*$/.test(token.string)) {
      token = tprop = {start: cur.ch, end: cur.ch, string: "", state: token.state,
                       type: token.string == "." ? "property" : null};
    }*/

    var variableNames = [];
    for( var line = 0; line < editor.lineCount() && line < editor.getCursor().line; line++ ){
      var lineContent = editor.getLine( line );
      var containsType = false;
      var typeIndex;

      for (var i = 0, e = types.length; i < e; ++i){
        typeIndex = lineContent.indexOf( types[i] );
        if( typeIndex != -1 ){
          containsType = true;
          break;
        }
      }

      if( containsType ){
        var variableName = lineContent.substring( typeIndex );
        variableName = variableName.substring( variableName.search( /\s/ ) );
        variableName = variableName.replace(/\s+/g, '');
        variableName = variableName.substring( 0, variableName.search( /[^A-Za-z]/ ) );
        if( variableName != "main" )
          variableNames.push( variableName );
      }
      
    }

    return {list: getCompletions(token, variableNames, options),
            from: {line: cur.line, ch: token.start},
            to: {line: cur.line, ch: token.end}};
  }

  CodeMirror.glslHint = function(editor, options) {
    return scriptHint(editor,
                      function (e, cur) {return e.getTokenAt(cur);},
                      options);
  };


  function getCompletions(token, variableNames, options) {
    var found = [], start = token.string;
    function maybeAdd(str) {
      if (str.indexOf(start) == 0 && !arrayContains(found, str)) found.push(str);
    }
    for (var i = 0; i < variableNames.length; i++){
      maybeAdd( variableNames[i] );
    }

    forEach(types, maybeAdd);
    forEach(typesQualifiers, maybeAdd);
    forEach(preProcessor, maybeAdd);
    forEach(keywords, maybeAdd);
    forEach(builtins, maybeAdd);
    return found;
  }

  function javascriptHint(editor, options) {
    return scriptHint(editor,
                      function (e, cur) {return e.getTokenAt(cur);},
                      options);
  };
  CodeMirror.registerHelper("hint", "sal", javascriptHint);

});
