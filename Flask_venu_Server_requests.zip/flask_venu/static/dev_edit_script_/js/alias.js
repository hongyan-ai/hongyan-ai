
system_alias={"codes":[
    {'sName':'SP8.Line1.on',  'fName':'SendHex("AE 20 00 28 02 01 01 AC");'}, 
    {'sName':'SP8.Line1.off', 'fName':'SendHex("AE 20 00 28 02 01 00 AC");'}, 

    {'sName':'SP8.Line2.on',  'fName':'SendHex("AE 20 00 28 02 02 01 AC");'}, 
    {'sName':'SP8.Line2.off', 'fName':'SendHex("AE 20 00 28 02 02 00 AC");'}, 

    {'sName':'SP8.Line3.on',  'fName':'SendHex("AE 20 00 28 02 03 01 AC");'}, 
    {'sName':'SP8.Line3.off', 'fName':'SendHex("AE 20 00 28 02 03 00 AC");'}, 

    {'sName':'SP8.Line4.on',  'fName':'SendHex("AE 20 00 28 02 04 01 AC");'}, 
    {'sName':'SP8.Line4.off', 'fName':'SendHex("AE 20 00 28 02 04 00 AC");'}, 

    {'sName':'SP8.Line5.on',  'fName':'SendHex("AE 20 00 28 02 05 01 AC");'}, 
    {'sName':'SP8.Line5.off', 'fName':'SendHex("AE 20 00 28 02 05 00 AC");'}, 

    {'sName':'SP8.Line6.on',  'fName':'SendHex("AE 20 00 28 02 06 01 AC");'}, 
    {'sName':'SP8.Line6.off', 'fName':'SendHex("AE 20 00 28 02 06 00 AC");'}, 

    {'sName':'SP8.Line7.on',  'fName':'SendHex("AE 20 00 28 02 07 01 AC");'}, 
    {'sName':'SP8.Line7.off', 'fName':'SendHex("AE 20 00 28 02 07 00 AC");'}, 

    {'sName':'SP8.Line8.on',  'fName':'SendHex("AE 20 00 28 02 08 01 AC");'}, 
    {'sName':'SP8.Line8.off', 'fName':'SendHex("AE 20 00 28 02 08 00 AC");'}, 

    {'sName':'SP8.LineALL.on','fName':'SendHex("AE 20 00 2A 01 01 AC");'}, 
    {'sName':'SP8.LineALL.off', 'fName':'SendHex("AE 20 00 2A 01 00 AC");'}, 
	
    {'sName':'SP82.Line1.on',  'fName':'SendHex("55 09 00 00 70 01 01 2C AA");'}, 
    {'sName':'SP82.Line1.off', 'fName':'SendHex("55 09 00 00 70 01 00 2D AA");'}, 

    {'sName':'SP82.Line2.on',  'fName':'SendHex("55 09 00 00 70 02 01 2F AA");'}, 
    {'sName':'SP82.Line2.off', 'fName':'SendHex("55 09 00 00 70 02 00 2E AA");'}, 

    {'sName':'SP82.Line3.on',  'fName':'SendHex("55 09 00 00 70 03 01 2E AA");'}, 
    {'sName':'SP82.Line3.off', 'fName':'SendHex("55 09 00 00 70 03 00 2F AA");'}, 

    {'sName':'SP82.Line4.on',  'fName':'SendHex("55 09 00 00 70 04 01 29 AA");'}, 
    {'sName':'SP82.Line4.off', 'fName':'SendHex("55 09 00 00 70 04 00 28 AA");'}, 

    {'sName':'SP82.Line5.on',  'fName':'SendHex("55 09 00 00 70 05 01 28 AA");'}, 
    {'sName':'SP82.Line5.off', 'fName':'SendHex("55 09 00 00 70 05 00 29 AA");'}, 

    {'sName':'SP82.Line6.on',  'fName':'SendHex("55 09 00 00 70 06 01 2B AA");'}, 
    {'sName':'SP82.Line6.off', 'fName':'SendHex("55 09 00 00 70 06 00 2A AA");'}, 

    {'sName':'SP82.Line7.on',  'fName':'SendHex("55 09 00 00 70 07 01 2A AA");'}, 
    {'sName':'SP82.Line7.off', 'fName':'SendHex("55 09 00 00 70 07 00 2B AA");'}, 

    {'sName':'SP82.Line8.on',  'fName':'SendHex("55 09 00 00 70 08 01 25 AA");'}, 
    {'sName':'SP82.Line8.off', 'fName':'SendHex("55 09 00 00 70 08 00 24 AA");'}, 

    {'sName':'SP82.LineALL.on','fName':'SendHex("55 08 00 00 71 01 2D AA");'}, 
    {'sName':'SP82.LineALL.off', 'fName':'SendHex("55 08 00 00 71 00 2C AA");'}, 
	

    {'sName':'WP8.Line1.on',  'fName':'SendHex("CA 20 F0 18 02 01 01 AC");'}, 
    {'sName':'WP8.Line1.off', 'fName':'SendHex("CA 20 F0 18 02 01 00 AC");'}, 
    {'sName':'WP8.Line2.on',  'fName':'SendHex("CA 20 F0 18 02 02 01 AC");'}, 
    {'sName':'WP8.Line2.off', 'fName':'SendHex("CA 20 F0 18 02 02 00 AC");'}, 
    {'sName':'WP8.Line3.on',  'fName':'SendHex("CA 20 F0 18 02 03 01 AC");'}, 
    {'sName':'WP8.Line3.off', 'fName':'SendHex("CA 20 F0 18 02 03 00 AC");'}, 
    {'sName':'WP8.Line4.on',  'fName':'SendHex("CA 20 F0 18 02 04 01 AC");'}, 
    {'sName':'WP8.Line4.off', 'fName':'SendHex("CA 20 F0 18 02 04 00 AC");'},
    {'sName':'WP8.Line5.on',  'fName':'SendHex("CA 20 F0 18 02 05 01 AC");'}, 
    {'sName':'WP8.Line5.off', 'fName':'SendHex("CA 20 F0 18 02 05 00 AC");'}, 
    {'sName':'WP8.Line6.on',  'fName':'SendHex("CA 20 F0 18 02 06 01 AC");'}, 
    {'sName':'WP8.Line6.off', 'fName':'SendHex("CA 20 F0 18 02 06 00 AC");'},
    {'sName':'WP8.Line7.on',  'fName':'SendHex("CA 20 F0 18 02 07 01 AC");'}, 
    {'sName':'WP8.Line7.off', 'fName':'SendHex("CA 20 F0 18 02 07 00 AC");'}, 
    {'sName':'WP8.Line8.on',  'fName':'SendHex("CA 20 F0 18 02 08 01 AC");'}, 
    {'sName':'WP8.Line8.off', 'fName':'SendHex("CA 20 F0 18 02 08 00 AC");'},
	
    {'sName':'WP8.LineALL.on',  'fName':'SendHex("CA 20 F0 19 03 FF FF 01 AC");'}, 
    {'sName':'WP8.LineALL.off', 'fName':'SendHex("CA 20 F0 19 03 FF 00 02 AC");'},	
	

	{'sName':'uptime.boots', 'fName':'$d198'},
	{'sName':'uptime.hours', 'fName':'$d199'},	
	
    {'sName':'IO.Check', 'fName':'uart0.send("53 69 AA DD 00 0D A1 FF 00 00 00 DD AA",1);'}	
]}


functions_alias={"functions":[
    {'sName':'SETKV',  'fName':'SetKV'}, 
    {'sName':'GETKV',  'fName':'GetKV'}, 	
    {'sName':'SAVEKV',  'fName':'SaveKV'}, 	
    {'sName':'FreeKV',  'fName':'FreeKV'}, 	
	{'sName':'SETUCI',  'fName':'SetUCI'}, 
    {'sName':'GETUCI',  'fName':'GetUCI'}, 
    {'sName':'SENDTCP', 'fName':'SendTCP'},
    {'sName':'SendUDP', 'fName':'SendUDP'},	
    {'sName':'SENDTOTOUCH', 'fName':'SendToTouch'},
	{'sName':'upd.send', 'fName':'udp.send'},
	{'sName':'SLEEP', 'fName':'sleep'},
	{'sName':'beep', 'fName':'beep'},	
	{'sName':'USLEEP', 'fName':'usleep'},
	{'sName':'MSLEEP', 'fName':'msleep'},
	{'sName':'ShowMessage', 'fName':'ShowMessage'},	
	{'sName':'SendToTouch', 'fName':'SendToTouch'},	
	{'sName':'SendToTouchPre', 'fName':'SendToTouchPre'},	
	{'sName':'SendToTouchOnce', 'fName':'SendToTouchOnce'},		
	{'sName':'SendToTouchRemove', 'fName':'SendToTouchRemove'},	
	{'sName':'SendIR', 'fName':'SendIR'},		
	{'sName':'SendIR2Port', 'fName':'SendIR2Port'},	
	{'sName':'LearnIR', 'fName':'LearnIR'},		
	{'sName':'SetTime', 'fName':'SetTime'},			
	{'sName':'gethostbyname', 'fName':'gethostbyname'},			
	{'sName':'socket_creat', 'fName':'socket_creat'},			
	{'sName':'socket_connect', 'fName':'socket_connect'},			
	{'sName':'socket_send', 'fName':'socket_send'},			
	{'sName':'socket_receive', 'fName':'l_Socket_receive'},			
	{'sName':'socket_close', 'fName':'socket_close'},			
							
	
	{'sName':'upd.sendhex', 'fName':'udp.sendhex'}	
]}

Errors_chinese={"errors":[
    {'sName':'Error:@Line',  'fName':'错误@行'},
    {'sName':'number expected',  'fName':'要求数字型'},
    {'sName':'string expected',  'fName':'要求字符型'},
    {'sName':'got no value',  'fName':'但是参数为空'},	

    {'sName':'unexpected symbol near',  'fName':'语法错误(你可能漏写了参数),在下面字符附近'},	
    {'sName':'got no value',  'fName':'但是参数为空'},
    {'sName':'attempt to call a nil value',  'fName':'值或函数不存在'},	
    {'sName':'attempt to index a nil value',  'fName':'对象不存在'},	
    {'sName':"'end' expected (to close",  'fName':'漏写end(结束函数'},
    {'sName':'at line',  'fName':'在行号'},		
	
    {'sName':'global',  'fName':'全局变量/函数'},	
    {'sName':'near',  'fName':'靠近'},		
	{'sName':'syntax error',  'fName':'语法错误'},	
	  {'sName':'not found',  'fName':'不存在'},	
	 
	  {'sName':'module',  'fName':'模块'},
	  
    {'sName':'bad argument',  'fName':'错误参数'}	
	
]}

function decodeAlias(_code)
{
	key="";
	value="";
	

	for(var i=0;i<system_alias.codes.length;i++)
	{
	key=(system_alias.codes[i].sName);
	value=(system_alias.codes[i].fName);
	
	_code=_code.replace(value, key);
	}
	
	return _code;
}

function encodeAlias(_code)
{
	key="";
	value="";
	
	
	
	for(var i=0;i<system_alias.codes.length;i++)
	{
	key=(system_alias.codes[i].sName);
	value=(system_alias.codes[i].fName);
	
	var regS = new RegExp(key, "gi");
	
	_code=_code.replace(regS,value);
	}
	
	return _code;
}

function AutoCorrectCode()
{
	var rCode=editor.getValue();
	var key;
	var value;
	rCode= rCode.replace(/\；/g,";");
	rCode= rCode.replace(/\（/g,"(");
	rCode= rCode.replace(/\）/g,")");
	rCode= rCode.replace(/\，/g,",");	
	rCode= rCode.replace(/\。/g,".");	
	rCode= rCode.replace(/\’/g,"'");	
	rCode= rCode.replace(/\“/g,'"');
	rCode= rCode.replace(/\”/g,'"');	
	ShowDebugMsg("正在检查半角字符....");
	//rCode= rCode.replace(/\SETKV/gi,"SetKV");	
	for(var i=0;i<functions_alias.functions.length;i++)
	{
	key=(functions_alias.functions[i].sName);
	value=(functions_alias.functions[i].fName);
	
	rCode=rCode.replace(new RegExp(key,'gi'),value);
	
	
	}
	ShowDebugMsg("正在检查函数名称....");

	editor.setValue(rCode);
	
	SendRequest_SaveFile_Debug($('#FileName').val(),'print("OK");',Password);
	
	setTimeout('ShowDebugMsg("代码已修正,请继续调试!")',800);
	//for Enable the debug mode
	
}
function GetChineseError(data)
{
	var key="";
	var value="";
	var str=data;
	
	for(var i=0;i<Errors_chinese.errors.length;i++)
	{
	key=(Errors_chinese.errors[i].sName);
	value=(Errors_chinese.errors[i].fName);
	
	str=str.replace(key, value);
	}
	
	return str;	
	
}




