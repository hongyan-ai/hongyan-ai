		var ExportALL_CODE="";
		var FileIdx=""
		var CurrentExportFileName="";
		var ExportScripts=[];
		var Export_currentIdx=0;
		var Export_currentCount=0;
		var Export_FileName="SimFAS_SA8_Code.tsk";
		var Export_Target=1;
		function ProcessExportScriptMsg(msg)
			{
				
				ShowProcessStatus();	
				jsonstr=msg.substring(5);
				var jdata = eval('(' + jsonstr + ')');	
			    msgType=jdata['Type'];
				switch	(msgType)
				{
				case 'auth' :
					var status=jdata['status']	;
					On_ExportScriptLogin(status);
					break;				
				
				case 'Msg'	:
					
					//Show Script content
					msgFilename_=jdata['Filename'];
					if ((msgFilename_) && msgFilename_.length>0)
					{
					  On_Script_Export(msgFilename_,jdata);
					}
					
					ProcessDevInfo(jdata);
					
					
					break;
				}
				
					
				
			}
			
var  ObjDevInfo={};
			
function ProcessDevInfo(jdata)
{
	
var mtype=jdata['mType'];
		if (mtype>0)
		{
			var content=Base64_decode(jdata['Msg']);
			
			if ((!content)) return -1;
			var lines=content.split("\n");	
			
			if (lines.length>0) ObjDevInfo={};
			
			for(i=0;i<lines.length-1;i++)
			{
				uidata= lines[i].split("|");   
				var key=uidata[0];				
				if  ( (uidata.length>2) && ((key.indexOf("/")<0)) )
				{
					var value=uidata[1];	
					ObjDevInfo[key]=value;
					//console.log(key+":"+value);
					
				}
			}

			
		}
		
	
	
}			

			function On_ExportScriptLogin(status)
			{			
					if (status==1)
					{
						log("设备已连接");

						ShowInfo_LabelStatus("设备已连接");
					}
					else
						log("登录失败，请检查您的用户名和密码!");			

			}



		function ProcessImportScriptMsg(msg)
			{
				
				ShowProcessStatus();	
				jsonstr=msg.substring(5);
				var jdata = eval('(' + jsonstr + ')');	
			    msgType=jdata['Type'];
				switch	(msgType)
				{
				case 'auth' :
					var status=jdata['status']	;
					On_ExportScriptLogin(status);
					break;				
				
				case 'Msg'	:
					
					//Show Script content
					msgFilename_=jdata['Filename'];
					if ((msgFilename_) && msgFilename_.length>0)
					{
					  //On_Script_Export(msgFilename_,jdata);
					}
					else
					{
						On_Script_import(msgFilename_,jdata);
						
					}
					
					break;
				}
				
					
				
			}



function On_Script_import(fn,jdata)
{
	
			if  (isImporting && (typeof(jsonObject) !=="undefined"))
			{
 
			valuePercent=Math.round( ((jsonObject.length-CurrentImportID)/(jsonObject.length))*100 );
			if (valuePercent>100) valuePercent=100;
			$("#progBar").css("width",valuePercent + "%").text(valuePercent + "%");	
			$("#BT_Updload").html("正在导入 "+valuePercent + "%");
			
			
			
				if (CurrentImportID<1)
				{
				$("#BT_Updload").attr("disabled", false);
				$("#UpDateBinFile").attr("disabled", false);					
					isImporting=false;
					$("#BT_Updload").hide();
					$("#BT_CloseUpdload").show();
					
					if (ImportAutoRunTask.length>3) RunTask(ImportAutoRunTask); 
					
				}

			
			
			}	

			
			
			if  ( (typeof(jsonObject) !=="undefined") &&  (CurrentImportID>-1) )  // &&  (ImportScripts.indexOf(jsonObject[CurrentImportID].SimName)>-1) )
			{
				//SendRequest_ImportFile(jsonObject[CurrentImportID].SimName, jsonObject[CurrentImportID].idx,jsonObject[CurrentImportID].Code,"");
				
				
				currentID=ImportScripts[CurrentImportID];
				SendRequest_ImportFile(jsonObject[currentID].SimName, jsonObject[currentID].idx,jsonObject[currentID].Code,"");
				
				//if (CurrentImportID==ImportScripts.length)
				CurrentImportID--;		
			
			
			}
	
}

		ImportAutoRunTask="";
		
		function ShowImportTask()
		{
			var importDesc="";			
			
			ImportAutoRunTask=" ";
			
			var AutoRunHTMLTag="";
			
			for(var i in jsonObject){
				if (i==0)
				{
					if ( typeof(jsonObject[i].AutoRun) !=="undefined" )  ImportAutoRunTask=jsonObject[i].AutoRun;
						
				}
				
				if (i>0)
				{
				checkBoxHTML='<input type="checkbox" value="'+jsonObject[i].SimName+'" checked /> '
				AutoRunHTMLTag="";
				if (ImportAutoRunTask.indexOf(jsonObject[i].SimName) !=-1)  AutoRunHTMLTag="<span class=\"label label-info\">自动运行</span>"
				
				importDesc=importDesc+checkBoxHTML+ (jsonObject[i].SimTitle + "(" + jsonObject[i].SimName+") ;  "+AutoRunHTMLTag+"<br/>");
				
				}
			}
			
			$("#importInfo").html("<h4>代码包共有("+(jsonObject.length-1)+")个程序，请选择并导入：</h4> <hr><a href=\"javascript:CheckBox_SelALL();\">全选/取消</a><br/> <br/>"+ importDesc);
			
			
		
		}
		
		function StartImport()
		{
		    
			ImportScripts=[];
			$('input:checkbox:checked').each(function (index, item) {
					selID=0;
					for(var i in jsonObject){
					
						if ( jsonObject[i].SimName==$(this).val())
						{
						ImportScripts.push(selID);
						}
						
						selID++;
						
					}
				
					
			});
			
			
			CurrentImportID=ImportScripts.length-1;
			
			if  (CurrentImportID>-1)  // &&  (ImportScripts.indexOf(jsonObject[CurrentImportID].SimName)>-1) )
			{
				$("#BT_Updload").html("正在导入");
				$("#BT_Updload").attr("disabled", true);
				$("#UpDateBinFile").attr("disabled", true);
				isImporting=true;
				currentID=ImportScripts[CurrentImportID];
				SendRequest_ImportFile(jsonObject[currentID].SimName, jsonObject[currentID].idx,jsonObject[currentID].Code,"");
			
			   
			   
				
				
				CurrentImportID--;		
			
			
			}

			
			
			
			
		}
		
			
function GetAliasName(idxString)
{

  var items=idxString.split("|");
  
  if (items.length<2) return "";
  
  var timeStr="";
  var captionAndIcon=items[2].split("^");
  
  if (captionAndIcon.length<2) return "";
  
 
  return (captionAndIcon[0]);
 
}

			
			function On_Script_Export(Filename_,jdata)
			{
						var bas64=new Base64();	
						var msgFilename=bas64.decode(Filename_);
						
						if ((msgFilename===CurrentExportFileName) && (FileEdited===false) )
						{
							  var msgFileContent=jdata['Msg'];
							  var IdxContent=jdata['Idx'];
							  //msgFileContent=bas64.decode(msgFileContent);
							  FileIdx=bas64.decode(IdxContent);
							  ExportALL_CODE=ExportALL_CODE+',\r\n{"SimTitle":"'+GetAliasName(FileIdx)+'","SimName":"'+msgFilename+'","idx":"'+IdxContent+'" , "Code":"'+msgFileContent+'"}';
							  //ExportALL_CODE=ExportALL_CODE +msgFileContent+"\r\n";
 
							 Export_currentIdx++;
							 if (Export_currentIdx<Export_currentCount)
							 {
											$("#label_uploadStatus").html("正在导出程序，请稍后...("+Export_currentIdx+"/"+Export_currentCount+")");
								 			if (Export_currentCount>5)
											{
												
												
												$("#StatusBarLabel").html("正在导出程序，请稍后...("+Export_currentIdx+"/"+Export_currentCount+")");
												$("#StatusBarLabel").show();			
				
											}
			
								 CurrentExportFileName=ExportScripts[Export_currentIdx];
 
								 SendRequest_LoadFile(CurrentExportFileName,"");							 
 	
							 }
							 else if (Export_currentIdx==Export_currentCount)
							 {
								 if (Export_Target==1)
								 {
									SaveFileToLocal(ExportALL_CODE);								 
								 }
								 
								 if (Export_Target==2)
								 {
									SaveToCodeStore(ExportALL_CODE);	
									$("#label_uploadStatus").html("已成功上传到云端.");
									
								 }								 
							
								 
								 $("#StatusBarLabel").hide();	
								 

							 }
						}				
			
			}
			
			
			function exportSelScript()
			{
			 
			var d = new Date();
			
			var dateStr=d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()+' '+d.getHours()+':'+d.getMinutes();
			
			Export_Target=1;
 	
			Export_FileName="SimFAS_SA8_Code_"+dateStr+".tsk";
			

			ExportDesc=$("#LocalFileDesc").val() ;
			cpRight=$("#LocalFileAuth").val()+ " www.SimFAS.com";
			autoRun=$("#LocalFileAutoRun").val();
			
			ExportScripts=[];
			ExportScripts.length=0;
			i=0;
			$('input:checkbox:checked').each(function (index, item) {
					if ( ($(this).val().length>0) &&  (ExportScripts.indexOf($(this).val())<0) )
					ExportScripts.push($(this).val());
			});
	

			
			ExportALL_CODE="";
			
			
			Export_currentCount=(ExportScripts.length);
			
			if (Export_currentCount>5)
			{
				$("#StatusBarLabel").html("正在导出程序，请稍后...");
				$("#StatusBarLabel").show();			
				
			}
			
			
			if (Export_currentCount>0)
			{
				
				
				var  APP_MAC=ObjDevInfo["MAC_ID"]; //"000102030405";
				APP_MAC=APP_MAC.replace(new RegExp(/( )/g),"");
				
				ExportDesc=$('#LocalFileAuth').val()+":" + $('#LocalFileDesc').val();
		
			ExportALL_CODE='{"Count":'+Export_currentCount+',"Desc":"'+ExportDesc+'","Date":"'+dateStr+'","Copyright":"'+cpRight+'","AutoRun":"'+autoRun+'","MacID": "'+APP_MAC+'"}';
			
			Export_currentIdx=0;
			CurrentExportFileName=ExportScripts[Export_currentIdx];
			
 
			
			SendRequest_LoadFile(CurrentExportFileName,"");	
			
			}
			else
			{
				alert("请选中您要导出的程序！");
			}
			
			}
			
			function SaveFileToLocal__(content)
			{
				
			var d = new Date();			
			var fileName="SimFAS_SA8_Code_"+d.getFullYear()+d.getMonth()+d.getDate()+d.getMinutes()+".tsk";
			var blob = new Blob([content], {type: "text/plain;charset=utf-8"});
			saveAs(blob, fileName);
				
			}

			function expTask(tName)
			{
			 
			var d = new Date();
			
			var dateStr=d.getFullYear()+'-'+d.getMonth()+'-'+d.getDate()+' '+d.getHours()+':'+d.getMinutes();
 
			Export_Target=1;

 
			ExportDesc=$("#LocalFileDesc").val() ;
			cpRight=$("#LocalFileAuth").val()+ " www.SimFAS.com";
			autoRun=$("#LocalFileAutoRun").val();
			
			
			Export_FileName="SimFAS_SA8_Export_"+tName;
			
			ExportScripts=[];
			ExportScripts.length=0;
			i=0;
			
			mutiExportScripts=[];
						$('input:checkbox:checked').each(function (index, item) {
					if ( ($(this).val().length>0) &&  (mutiExportScripts.indexOf($(this).val())<0) )
					mutiExportScripts.push($(this).val());
			});
			
			
			if (mutiExportScripts.length>1)
			{
				ExportScripts=mutiExportScripts;	
				Export_FileName="SimFAS_SA8_Export_"+dateStr+".tsk";
				
			}
			else	
			ExportScripts.push(tName);
			
			ExportALL_CODE="";
			
			
			Export_currentCount=(ExportScripts.length);
			
			if (Export_currentCount>5)
			{
				$("#StatusBarLabel").html("正在导出程序，请稍后...");
				$("#StatusBarLabel").show();			
				
			}

			
			if (Export_currentCount>0)
			{
			//ExportALL_CODE='{"Count":'+Export_currentCount+',"Desc":"'+ExportDesc+'","Data":"'+dateStr+'","copyright":"'+cpRight+'"}';
			ExportALL_CODE='{"Count":'+Export_currentCount+',"Desc":"'+ExportDesc+'","Date":"'+dateStr+'","Copyright":"'+cpRight+'","AutoRun":"'+autoRun+'"}';
				
			Export_currentIdx=0;
			CurrentExportFileName=ExportScripts[Export_currentIdx];
			

			
			SendRequest_LoadFile(CurrentExportFileName,"");	
			
			}
			else
			{
				alert("请选中您要导出的程序！");
			}
			
			}
			
			function SaveFileToLocal(content)
			{
			
			
			var blob = new Blob([content], {type: "text/plain;charset=utf-8"});
			saveAs(blob, Export_FileName);
				
			}
			

 
function exportSelScriptToStore()
			{
			 
			var d = new Date();
			
			var dateStr=d.getFullYear()+'-'+d.getMonth()+'-'+d.getDate()+' '+d.getHours()+':'+d.getMinutes();



		var APP_NAME=$('#codeName').val();
		var APP_DESC=$('#codeDesc').val();
		
		
		if ( APP_NAME.length<2)
		{
			$("#bt_toCloud").attr("disabled", false);		
			alert('请填写正确的程序名称！');	
			return;	
		}

		if  (APP_DESC.length<2) APP_DESC=APP_NAME;
		
			Export_Target=2;
 	
			Export_FileName="SimFAS_SA8_Code_"+dateStr+".tsk";
			

			//ExportDesc="描述";
			//cpRight="SimFAS";
			
			ExportDesc=$("#LocalFileDesc").val() ;
			cpRight=$("#LocalFileAuth").val()+ " www.SimFAS.com";
			autoRun=$("#codeAutoRun").val();
			
			
			
			ExportScripts=[];
			ExportScripts.length=0;
			i=0;
			$('input:checkbox:checked').each(function (index, item) {
					if ( ($(this).val().length>0) &&  (ExportScripts.indexOf($(this).val())<0) )
					ExportScripts.push($(this).val());
			});
	

			
			ExportALL_CODE="";
			
			
			Export_currentCount=(ExportScripts.length);
			

				
			
			if (Export_currentCount>2)
			{

				$("#StatusBarLabel").html("正在导出程序，请稍后...");
				$("#StatusBarLabel").show();	
				$("#bt_toCloud").attr("disabled", true);			
				
			}
			
			
			if (Export_currentCount>0)
			{
			//ExportALL_CODE='{"Count":'+Export_currentCount+',"Desc":"'+ExportDesc+'","Data":"'+dateStr+'","copyright":"'+cpRight+'"}';
			ExportALL_CODE='{"Count":'+Export_currentCount+',"Desc":"'+ExportDesc+'","Date":"'+dateStr+'","Copyright":"'+cpRight+'","AutoRun":"'+autoRun+'"}';

						
			
			Export_currentIdx=0;
			CurrentExportFileName=ExportScripts[Export_currentIdx];
			
 			//$('#Modal_Status').modal({backdrop: 'static', keyboard: false});
				
			$("#label_uploadStatus").html("正在导出程序，请稍后...");
			$("#upload_fillForm").hide();	
			$("#Div_uploadResult").show();	
			$("#bt_toCloud").attr("disabled", true);	
			
			SendRequest_LoadFile(CurrentExportFileName,"");	
			
			}
			else
			{
				alert("请选中您要导出的程序！");
			}
			
}
			
			
function SaveToCodeStore(exportTaskCode)
{

		var APP_TYPE=1;
		var APP_NAME=$('#codeName').val();
		var APP_DESC=$('#codeDesc').val();
		var  APP_CODE=exportTaskCode;
		var  APP_MAC=ObjDevInfo["MAC_ID"]; //"000102030405";
		var  APP_AUTHOR=$('#codeAuth').val();
		var  APP_PASS=$('#codePass').val();
		APP_MAC=APP_MAC.replace(new RegExp(/( )/g),"");
		var jsonData = {
        "action":"new",
		 "APP_NAME": APP_NAME,
        "APP_TYPE": APP_TYPE,
		"APP_DESC": APP_DESC,
		"APP_CODE": APP_CODE,
		"APP_MAC": APP_MAC,
		"APP_AUTHOR": APP_AUTHOR,
		"APP_PASS": APP_PASS
		};

		if (APP_NAME.length<2)
		{
		$("#bt_toCloud").attr("disabled", false);		
		alert('请填写正确的程序名称！');	
		return;	
		}
		
		if (APP_CODE.length<6)
		{
		$("#bt_toCloud").attr("disabled", false);		
		alert('代码有误！');	
		return;	
		}
		
		$.ajax({
			type: "POST",
			url: "http://www.simfas.cn/code/save.php",
			contentType: "application/json; charset=utf-8",
			data: JSON.stringify(jsonData),
			//data:$("input").serialize(),
			dataType: "json",
			
			success: function (message) {
				if (message > 0) {
                alert("代码已保存到云端."+message.ret);
				}
				
				$("#label_uploadStatus").html("<h3><i class=\"icon-ok\"></i> 程序上传成功</h3><br/><br/> 您可以使用关键字[<b class=\"text-primary\">"+APP_MAC+"</b>]在代码市场搜索到该程序!");
				
				$("#bt_toCloud").attr("disabled", false);	
				//$('#CodeList').show(); 
				//$('#Div_upload').hide(); 
				$('#Div_uploadResult').show(); 
				$('#resMAC').html(APP_MAC); 
				$('input:checkbox').prop("checked",false); 
				
				
			},
			
			error: function (message) {
					alert('错误信息:'+message);
 
					}			
			});
		
      
	
}
		

	function ShowUploadForm()
	{
		SendRequest_sysinfo("_reqSysinfo.tsk");
		
		uploadCounts=[];
		$('input:checkbox:checked').each(function (index, item) {
					if ( ($(this).val().length>0) &&  (uploadCounts.indexOf($(this).val())<0) )
					uploadCounts.push($(this).val());
			});
			
		if (uploadCounts.length>0)	
		{
			$('#CodeList').hide(); 
			$('#Div_upload').show(); 
			$("#codeAutoRun").val("");
			$(codeName).focus();
		}			
		else
		{
			alert("请选择要上传的程序!");		
		}
			
	
	}
	
	function CloaseUploadForm()
	{
	$('#CodeList').show();
	$("#upload_fillForm").show();	
	$('#Div_upload').hide();
	$('#Div_uploadResult').hide(); 
	$('#Div_Download').hide(); 
	
	}
	
	
	
function ShowDownLoadForm()
{
	SendRequest_sysinfo("_reqSysinfo.tsk");
	
	var downloadCounts=[];
				$('input:checkbox:checked').each(function (index, item) {
					if ( ($(this).val().length>0) &&  (downloadCounts.indexOf($(this).val())<0) )
					downloadCounts.push($(this).val());
			});
			
		if (downloadCounts.length>0)	
		{
			$('#Div_upload').hide();
			$('#CodeList').hide(); 
			$('#Div_Download').show(); 			
			$("#LocalFileDesc").focus();
			$("#LocalFileAutoRun").val("");
		}			
		else
		{
			alert("请选择要导出的程序!");		
		}
		
	
	
}	

function CloseDownLoadForm()
	{
	$('#CodeList').show();
	$('#Div_upload').hide();
	$('#Div_uploadResult').hide(); 
	$('#Div_Download').hide(); 
	
	}
	
	
function CreateBlockHTML(id,title,desc)
{
	
return	'<a href="javascript:importFrom('+id+')" title="'+title+":"+desc+'"><div class="col-md-2 col-sm-12 col-xs-12"  ><div class="panel panel-info text-center no-boder bg-color-blue"><div class="panel-body"><i class="fa fa-bar-chart-o fa-5x"></i> '+truncateChinese(title)+' </div> <div class="panel-footer back-footer-blue"><i class="icon-download-alt"></i></div> </div></div></a>';

}	
	
	
function GetCodeListFromStore(action,keyword)
{

		var jsonData = {
        "action":action,
		 "keyword": keyword,
		};
	
		$.ajax({
			type: "POST",
			url: "http://www.simfas.cn/code/get.php",
			contentType: "application/json; charset=utf-8",
			data: JSON.stringify(jsonData),
			//data:$("input").serialize(),
			dataType: "json",
			
			success: function (message) {

				
				
				if (message.length>1)
				{				
	 
					
					if (message[0].action=="list_own")
					{
						
						AddCodeListTodiv("My20",message) ; 
					}
					
					if (message[0].action=="list_top")
					{
						
						AddCodeListTodiv("top20",message) ; 
					}

					if (message[0].action=="list_new")
					{
						
						AddCodeListTodiv("New20",message) ; 
					}

					if (message[0].action=="list_search")
					{
						$("#labelKeyword").html("为您找到"+(message.length-1)+"个关于["+keyword+']的程序');
						$("#downloadDIV").hide();
						$("#defaultShowDiv").hide();
						$("#SearchDIV").show();
						AddCodeListTodiv("SearchResult",message) ; 
					}

					
					
				}
				if ((message.length==1) &&  (message[0].action=="list_search"))
				{
					
					$("#labelKeyword").html("关键字："+keyword);
					$("#SearchResult").html('<div class="alert alert-warning alert-dismissable">没有找到您要的程序[ <b>'+keyword+'</b> ]，请更换关键字！</div>');
					
				}
					
				
				
			},
			
			error: function (message) {
					alert('错误信息:'+message);
					}			
			});
		
      
	
}

function AddCodeListTodiv(divName,jdata)
{
	var FullHTML=" ";
	for(var i in jdata){
					if (i>0)
					{
						if ( jdata[i].APP_NAME)
						{
						FullHTML=FullHTML+CreateBlockHTML(jdata[i].ID,jdata[i].APP_NAME,jdata[i].APP_DESC);
						}
						
					}
						
	}
	$("#"+divName).html(FullHTML);
	
}

function importFrom(id)
{
	
		var jsonData = {
        "action":"download",
		 "keyword": id,
		};
	
		$.ajax({
			type: "POST",
			url: "http://www.simfas.cn/code/get.php",
			contentType: "application/json; charset=utf-8",
			data: JSON.stringify(jsonData),
			//data:$("input").serialize(),
			dataType: "json",
			
			success: function (message) {

				
				
				if (message.length>1)
				{		
					HTML_appName=message[1].APP_NAME;
					HTML_appDesc=message[1].APP_DESC;
					JsCode=(message[1].APP_CODE);
					jsonObject= jQuery.parseJSON("["+JsCode+"]");
					$("#defaultShowDiv").hide();
					$("#SearchDIV").hide();
					$("#downloadDIV").show();
					$("#BT_Updload").show();
					$("#BT_Updload").html("云端导入");
					$("#BT_Updload").attr("disabled", false);
					$("#BT_CloseUpdload").hide();
					ShowDownloadInfo(HTML_appName,HTML_appDesc);		
					ShowImportTask();
					
				}
				
			},
			
			error: function (message) {
					alert('错误信息:'+message);
					}			
			});
			
	
	
}

function truncateChinese(str) {
var newStr = '';
var maxChineseW=16;
var len = 0;
for (var i = 0; i < str.length; i++) {
var c = str.charAt(i);
if (/[\u4e00-\u9fa5]/.test(c)) {
len += 2;
if (len <= maxChineseW) {
newStr += c;
}
} else {
len++;
if (len <= maxChineseW) {
newStr += c;
}
}
}
if (len > maxChineseW) {
newStr = newStr.substring(0, maxChineseW/2) + '...';
}
return newStr;
}


function ShowDownloadInfo(name,desc)
{
	
$("#downloadInfo").html("<h4><b>"+name+"</b> </h4><br>&emsp;&emsp;"+(desc)+"	<br><hr>");	
	
}

var LastSelStatus=false;
function CheckBox_SelALL()
{
	
	$('input:checkbox').prop("checked",LastSelStatus); 	
	
	LastSelStatus= ! LastSelStatus;
	
}
	
			